-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 40_rls_status_audit.sql        (Khami 10 ka baqaya)
--  SIRF PARHTA HAI — kuch badalta NAHI. Bekhauf chalayein.
--
--  KYUN: 10_subscription_enforcement.sql ne har content table par
--  RESTRICTIVE write-gate laga di. Magar Postgres me restrictive
--  policy SIRF us table par asar karti hai jahan RLS PEHLE SE ON ho.
--  Jis table par RLS OFF hai, wahan subscription gate BILKUL BE-ASAR
--  hai — yaani mo'attal afsar wahan likh sakta hai.
--
--  Ye script batati hai: kis gated table par RLS on hai, kis par nahi,
--  aur har aik par kitni policies hain.
-- ════════════════════════════════════════════════════════════════

with gated(t) as (
  select unnest(array[
    'cases','case_documents','case_document_versions','case_accused','case_witnesses',
    'suspects','evidence','zimni_reports','zimni_androoni_reports','fir_matn','fir_copies',
    'incident_reports','rfa_forms','cdr_imei_requests','cro_cards','ahkamat',
    'sarkari_gari','hamrahi_mulazman','reminders','court_dates','templates'
  ])
)
select
  g.t                                            as "table",
  case when c.oid is null then 'MOJOOD NAHI'
       when c.relrowsecurity then 'RLS ON'
       else '>>> RLS OFF — gate be-asar <<<' end  as "halat",
  coalesce(p.total, 0)                            as "kul policies",
  coalesce(p.restrictive, 0)                      as "restrictive",
  coalesce(p.sub_gate, 0)                         as "subscription gate",
  coalesce(p.selects, 0)                          as "select policies"
from gated g
left join pg_class c
       on c.relname = g.t
      and c.relnamespace = 'public'::regnamespace
      and c.relkind = 'r'
left join lateral (
  select count(*)                                              as total,
         count(*) filter (where not pol.polpermissive)         as restrictive,
         count(*) filter (where pol.polname like 'dio_sub_%')  as sub_gate,
         count(*) filter (where pol.polcmd in ('r','*'))       as selects
  from pg_policy pol
  where pol.polrelid = c.oid
) p on true
order by
  case when c.oid is null then 2
       when c.relrowsecurity then 1
       else 0 end,        -- RLS OFF sab se upar (yahi masla hai)
  g.t;

-- ── Khulasa ────────────────────────────────────────────────────
with gated(t) as (
  select unnest(array[
    'cases','case_documents','case_document_versions','case_accused','case_witnesses',
    'suspects','evidence','zimni_reports','zimni_androoni_reports','fir_matn','fir_copies',
    'incident_reports','rfa_forms','cdr_imei_requests','cro_cards','ahkamat',
    'sarkari_gari','hamrahi_mulazman','reminders','court_dates','templates'
  ])
)
select
  count(*) filter (where c.oid is not null and c.relrowsecurity)       as "RLS ON",
  count(*) filter (where c.oid is not null and not c.relrowsecurity)   as "RLS OFF (gate be-asar)",
  count(*) filter (where c.oid is null)                                as "table mojood nahi"
from gated g
left join pg_class c
       on c.relname = g.t
      and c.relnamespace = 'public'::regnamespace
      and c.relkind = 'r';
