-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 60_subscriptions_lockdown.sql        [SAB SE AHEM]
--
--  SAB SE BARI KHAMI: `dio_has_active_sub()` faisla `subscriptions`
--  table se karta hai — MAGAR wahi table afsar ke liye KHULI thi
--  (na RLS, na policy; client whitelist me bhi "tajdeed ke liye")۔
--  Yaani aik hi call:
--      insert into subscriptions(officer_id,status,expires_at)
--      values (<apna id>,'active','2099-01-01');
--  aur poora nafaz — 21 tables ki write-gate, mo'attali, sab — BAND.
--  Phir Edge Function usi jaali row par dastkhat-shuda license bhi de deta.
--
--  YE SCRIPT: afsar apni subscription PARH sakta hai, magar status/miyaad
--  KHUD nahi likh sakta. Tajdeed ab `dio_request_subscription()` se hoti
--  hai jo sirf 'pending' row banata hai — 'active' sirf admin/service_role.
--
--  PEHLE 10 aur 50 chal chuki hon. WAPSI: 60_..._ROLLBACK.sql
-- ════════════════════════════════════════════════════════════════

-- ── 1) Apna officer id (baar baar chahiye) ─────────────────────
create or replace function public.dio_my_officer_id()
returns uuid
language sql
stable
security definer
set search_path = pg_catalog, public, pg_temp
as $$
  select o.id from public.officers o where o.user_id = auth.uid() limit 1;
$$;
revoke all on function public.dio_my_officer_id() from public;
grant execute on function public.dio_my_officer_id() to authenticated;

-- ── 2) subscriptions par RLS: parho apna, likho kuch nahi ──────
alter table public.subscriptions enable row level security;

drop policy if exists dio_sub_read_own  on public.subscriptions;
create policy dio_sub_read_own on public.subscriptions
  as permissive for select to authenticated
  using (officer_id = public.dio_my_officer_id());

-- Admin/superadmin apne idare ki sab dekh saken
drop policy if exists dio_sub_read_admin on public.subscriptions;
create policy dio_sub_read_admin on public.subscriptions
  as permissive for select to authenticated
  using (exists (select 1 from public.officers o
                 where o.user_id = auth.uid()
                   and o.role in ('admin','superadmin')
                   and coalesce(o.is_suspended,false) = false));

-- Koi INSERT/UPDATE/DELETE policy JAAN-BOOJH kar nahi banayi:
-- RLS on + koi permissive write policy nahi = authenticated likh hi nahi sakta.
-- (service_role RLS bypass karta hai, is liye admin panel/Edge Function chalte hain.)
drop policy if exists dio_sub_write_own on public.subscriptions;

-- subscription_plans: sab parh saken, koi likh na sake
alter table public.subscription_plans enable row level security;
drop policy if exists dio_plans_read on public.subscription_plans;
create policy dio_plans_read on public.subscription_plans
  as permissive for select to authenticated using (true);

-- ── 3) Tajdeed ka MEHFOOZ raasta (sirf 'pending' banata hai) ───
create or replace function public.dio_request_subscription(
  p_plan_id  uuid    default null,
  p_amount   numeric default null,
  p_ref      text    default null
)
returns uuid
language plpgsql
security definer
set search_path = pg_catalog, public, pg_temp
as $$
declare
  v_oid uuid;
  v_id  uuid;
begin
  v_oid := public.dio_my_officer_id();
  if v_oid is null then
    raise exception 'afsar ka record nahi mila';
  end if;

  -- Mo'attal/ghair-manzoor afsar darkhwast bhi na de
  if exists (select 1 from public.officers o
             where o.id = v_oid
               and (coalesce(o.is_suspended,false) = true
                 or coalesce(o.is_approved,false)  = false)) then
    raise exception 'aap ka account mo''attal ya ghair-manzoor hai';
  end if;

  -- Spam roko: aik waqt me aik hi zer-e-ghaur darkhwast
  if exists (select 1 from public.subscriptions s
             where s.officer_id = v_oid and s.status = 'pending'
               and s.created_at > now() - interval '24 hours') then
    raise exception 'aap ki darkhwast pehle se zer-e-ghaur hai';
  end if;

  insert into public.subscriptions (officer_id, status, amount, payment_method, started_at, expires_at)
  values (v_oid, 'pending', p_amount, coalesce(p_ref,'request'), now(), null)
  returning id into v_id;

  return v_id;
end $$;
revoke all on function public.dio_request_subscription(uuid, numeric, text) from public;
grant execute on function public.dio_request_subscription(uuid, numeric, text) to authenticated;

-- ── 4) TASDEEQ ────────────────────────────────────────────────
select
  (select count(*) from pg_policy p
    where p.polrelid = 'public.subscriptions'::regclass
      and p.polcmd in ('a','w','d')                    -- insert/update/delete
      and p.polpermissive)                              as "likhne ki policies (0 honi chahiye)",
  (select relrowsecurity from pg_class
    where oid = 'public.subscriptions'::regclass)       as "subscriptions RLS on";
