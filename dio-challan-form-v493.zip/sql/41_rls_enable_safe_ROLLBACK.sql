-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 41_rls_enable_safe_ROLLBACK.sql
--  41_rls_enable_safe.sql ko wapas palatta hai: RLS band aur
--  dio_base_all policy hataata hai. Subscription gate (dio_sub_*)
--  ko HAATH NAHI LAGATA — wo 10_..._ROLLBACK.sql se hatti hai.
--  RLS off hote hi gate khud-ba-khud be-asar ho jati hai.
-- ════════════════════════════════════════════════════════════════
do $$
declare
  t     text;
  gated text[] := array[
    'cases','case_documents','case_document_versions','case_accused','case_witnesses',
    'suspects','evidence','zimni_reports','zimni_androoni_reports','fir_matn','fir_copies',
    'incident_reports','rfa_forms','cdr_imei_requests','cro_cards','ahkamat',
    'sarkari_gari','hamrahi_mulazman','reminders','court_dates','templates'
  ];
begin
  foreach t in array gated loop
    -- SIRF wahi tables jin par 41 ne KHUD RLS on kiya tha. Pehle ye
    -- 21 ki 21 par chalta tha — jin tables par pehle se apni per-officer
    -- policies theen un ki RLS bhi band kar deta, yaani rollback system ko
    -- pehle se ZYADA khula chhoR deta tha.
    if not exists (select 1 from public.dio_migration_state
                   where script = '41' and item = 'rls:'||t) then
      raise notice 'CHHORA (41 ne ise on nahi kiya tha): %', t;
      continue;
    end if;
    if exists (
      select 1 from pg_class c
      where c.relname = t
        and c.relnamespace = 'public'::regnamespace
        and c.relkind in ('r','p')
    ) then
      execute format('alter table public.%I disable row level security', t);
      execute format('drop policy if exists dio_base_all on public.%I', t);
      delete from public.dio_migration_state where script='41' and item='rls:'||t;
      raise notice 'Wapas: % (RLS off, dio_base_all hataai)', t;
    end if;
  end loop;
end $$;
