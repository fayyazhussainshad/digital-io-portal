-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 50_suspend_hard_gate_ROLLBACK.sql
--  dio_has_active_sub() ko 10_subscription_enforcement.sql wali
--  purani shakl par wapas le jata hai (mo'attali check ke baghair).
--  NOTE: is ke baad mo'attal ADMIN dobara likh sakega — sirf tab
--  chalayein jab 50 se koi masla bana ho.
-- ════════════════════════════════════════════════════════════════
create or replace function public.dio_has_active_sub()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    exists (
      select 1 from public.officers o
      where o.user_id = auth.uid()
        and o.role in ('superadmin', 'admin')
    )
    or
    exists (
      select 1
      from public.officers o
      join public.subscriptions s on s.officer_id = o.id
      where o.user_id = auth.uid()
        and s.status in ('active', 'trial')
        and s.expires_at > now()
    );
$$;
grant execute on function public.dio_has_active_sub() to authenticated;
