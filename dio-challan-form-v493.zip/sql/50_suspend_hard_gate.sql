-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 50_suspend_hard_gate.sql
--  MAQSAD: "koi mo'attal afsar bina subscription system me na aaye"
--
--  MASLA JO MILA:
--    (1) auth.js me mo'attali ka check GHALAT column par tha
--        (`officer.suspended` jabke DB me `is_suspended` hai) — yaani
--        gate kabhi chala hi nahi. [client side theek kar diya gaya]
--    (2) `dio_has_active_sub()` mo'attali dekhti hi NAHI thi — aur
--        `admin` ko poora mustasna kar deti thi. To aik MO'ATTAL ADMIN
--        ya aisa afsar jis ka client bypass ho jaye, DB par likh sakta tha.
--
--  YE SCRIPT dio_has_active_sub() ko dobara likhta hai, is tarteeb se:
--     1. superadmin (maalik)            → HAMESHA true (kabhi band nahi)
--     2. is_suspended = true            → FALSE  (admin ho ya afsar)
--     3. is_approved = false            → FALSE  (ghair-manzoor shuda)
--     4. admin (mo'attal nahi)          → true
--     5. warna                          → faal/trial subscription + miyaad baqi
--
--  10_subscription_enforcement.sql PEHLE chal chuki honi chahiye (wo
--  policies banati hai); ye sirf function badalta hai, policies ko haath
--  nahi lagata — is liye foran, bina kisi rukawat ke lagu ho jata hai.
--  WAPSI: 50_suspend_hard_gate_ROLLBACK.sql
-- ════════════════════════════════════════════════════════════════

-- 10 pehle chali? warna ye sirf aik function banata hai jise koi nahi bulata
do $guard$
begin
  if not exists (select 1 from pg_policy where polname like 'dio_sub_%') then
    raise exception '10_subscription_enforcement.sql PEHLE chalayein — warna ye script kuch nafiz nahi karti';
  end if;
end $guard$;

create or replace function public.dio_has_active_sub()
returns boolean
language sql
stable
security definer
set search_path = pg_catalog, public, pg_temp
as $$
  select
    -- 1) Maalik — hamesha ijazat
    exists (
      select 1 from public.officers o
      where o.user_id = auth.uid()
        and o.role = 'superadmin'
    )
    or (
      -- 2/3) Mo'attal ya ghair-manzoor shuda → koi ijazat nahi
      not exists (
        select 1 from public.officers o
        where o.user_id = auth.uid()
          and (coalesce(o.is_suspended, false) = true
               or coalesce(o.is_approved, false) = false)  -- NULL = ghair-manzoor (fail-closed)
      )
      and (
        -- 4) Admin (mo'attal nahi)
        exists (
          select 1 from public.officers o
          where o.user_id = auth.uid()
            and o.role = 'admin'
        )
        or
        -- 5) Aam afsar — faal/trial subscription jis ki miyaad baqi ho
        exists (
          select 1
          from public.officers o
          join public.subscriptions s on s.officer_id = o.id
          where o.user_id = auth.uid()
            and s.status in ('active', 'trial')
            -- expires_at NULL: 'active' = mustaqil (manually diya gaya),
            -- 'trial' = na-mukammal record, qabool nahi. Pehle NULL par
            -- `> now()` NULL deta tha aur asli paying afsar BLOCK ho jata.
            and (case when s.status = 'active' then (s.expires_at is null or s.expires_at > now())
                      else s.expires_at > now() end)
        )
      )
    );
$$;

revoke all on function public.dio_has_active_sub() from public;
grant execute on function public.dio_has_active_sub() to authenticated;

comment on function public.dio_has_active_sub() is
  'DIO write-gate: superadmin hamesha; mo''attal/ghair-manzoor kabhi nahi; '
  'admin agar mo''attal nahi; warna faal ya trial subscription jis ki miyaad baqi ho.';

-- ── TASDEEQ (ikhtiyari): apne liye nateeja dekhein ─────────────
-- select public.dio_has_active_sub();
