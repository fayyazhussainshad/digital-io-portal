-- ============================================================================
-- Digital IO — 20_officers_protect_trigger.sql   (Finding 6 ka DB juRwa)
-- ----------------------------------------------------------------------------
-- Qadam 1 me client-side allowlist laga (data-api.js). Ye us ki DB-level zamanat
-- hai: koi bhi aam officer client se apna role/is_approved/is_suspended/user_id
-- NAHI badal sakta — chahe wo API seedha call kare. Admin/superadmin aur backend
-- (service_role) ko chhoot hai (wahi approve/suspend karte hain).
--
-- Columns (code se tasdeeq-shuda): officers.role, is_approved, is_suspended, user_id.
-- NOTE: agar 00_export_current_schema.sql se pata chale ke officers me aur hassas
-- columns bhi hain (jaise approved_by/approved_at), to unhe neeche list me shamil
-- kar lein (sirf WAJOOD-shuda columns reference karein warna trigger error dega).
--
-- Rollback: 20_officers_protect_trigger_ROLLBACK.sql
-- ============================================================================

create or replace function public.dio_protect_officer_columns()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  is_priv boolean;
begin
  -- backend/service_role (koi JWT nahi) → sab allow
  if auth.uid() is null then
    return new;
  end if;

  -- admin/superadmin → sab allow (wahi approve/suspend karte hain)
  select exists (
    select 1 from public.officers o
    where o.user_id = auth.uid() and o.role in ('superadmin', 'admin')
  ) into is_priv;

  if is_priv then
    return new;
  end if;

  -- Aam officer: hassas columns ko purani value par WAPAS (khamoshi se ignore)
  new.role         := old.role;
  new.is_approved  := old.is_approved;
  new.is_suspended := old.is_suspended;
  new.user_id      := old.user_id;

  return new;
end;
$$;

drop trigger if exists dio_protect_officer_columns on public.officers;
create trigger dio_protect_officer_columns
  before update on public.officers
  for each row
  execute function public.dio_protect_officer_columns();

-- TASDEEQ:
--   aam officer se: update officers set role='admin', station='X' where id=<apna>;
--   → station badal jaye, role WAISA HI rahe (revert).
--   admin se wahi update → role bhi badal jaye.
