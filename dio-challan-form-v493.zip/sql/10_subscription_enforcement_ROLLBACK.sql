-- ============================================================================
-- Digital IO — 10_subscription_enforcement_ROLLBACK.sql
-- 10_subscription_enforcement.sql ki har cheez wapas hata deta hai.
-- Agar enforcement ke baad koi masla ho to ye chala den — sab pehle jaisa.
-- ============================================================================

do $$
declare
  t text;
  gated text[] := array[
    'cases','case_documents','case_document_versions','case_accused','case_witnesses',
    'suspects','evidence','zimni_reports','zimni_androoni_reports','fir_matn','fir_copies',
    'incident_reports','rfa_forms','cdr_imei_requests','cro_cards','ahkamat','sarkari_gari',
    'hamrahi_mulazman','reminders','court_dates','templates'
  ];
begin
  foreach t in array gated loop
    if to_regclass('public.' || t) is null then continue; end if;
    execute format('drop policy if exists dio_sub_ins on public.%I', t);
    execute format('drop policy if exists dio_sub_upd on public.%I', t);
    execute format('drop policy if exists dio_sub_del on public.%I', t);
    raise notice 'GATE HATAYI: %', t;
  end loop;
end $$;

drop function if exists public.dio_has_active_sub();
