-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 41_rls_enable_safe.sql          (Khami 10 ko BAND)
--  PEHLE 40_rls_status_audit.sql chalayein aur dekhein kaun si tables
--  'RLS OFF' hain. Phir ye script chalayein.
--
--  YE KYA KARTA HAI (aur kyun mehfooz hai):
--    Har gated table par:
--      (a) pehle aik PERMISSIVE "allow-all to authenticated" policy
--          banata hai  →  parhna/likhna jaisa pehle tha, kuch nahi tootta;
--      (b) PHIR RLS enable karta hai.
--    Tarteeb ahem hai: policy PEHLE, RLS BAAD me — is liye aik lamha
--    bhi aisa nahi aata jab table band ho jaye.
--
--  ASAR: RLS on hote hi 10_subscription_enforcement.sql ki pehle se
--  mojood RESTRICTIVE write-gate JAAG jati hai. Postgres me natija =
--  (koi bhi permissive TRUE) AND (sab restrictive TRUE). Yaani:
--    • parhna      → pehle jaisa (allow-all permissive)
--    • likhna      → SIRF jab subscription faal ho
--
--  NOTE: ye allow-all policy per-officer scoping NAHI karti — wo app ki
--  apni query-level scoping (mine()/eq('officer_id')) par hai, jaisa
--  aaj bhi hai. Ye script sirf subscription gate ko FAAL karta hai;
--  scoping sakht karna aik alag, alag se test hone wala qadam hai.
--
--  WAPSI: 41_rls_enable_safe_ROLLBACK.sql
-- ════════════════════════════════════════════════════════════════

-- 41 ne KIN tables par RLS on kiya — ye rollback ke liye zaroori hai
do $g$ begin
  if to_regprocedure('public.dio_has_active_sub()') is null then
    raise exception '10_subscription_enforcement.sql PEHLE chalayein — warna RLS on ho jayegi magar koi gate nahi hogi';
  end if;
end $g$;

create table if not exists public.dio_migration_state (
  script text, item text, at timestamptz default now(), primary key (script, item));

do $$
declare
  t            text;
  gated        text[] := array[
    'cases','case_documents','case_document_versions','case_accused','case_witnesses',
    'suspects','evidence','zimni_reports','zimni_androoni_reports','fir_matn','fir_copies',
    'incident_reports','rfa_forms','cdr_imei_requests','cro_cards','ahkamat',
    'sarkari_gari','hamrahi_mulazman','reminders','court_dates','templates'
  ];
  had_rls      boolean;
  c_oid        oid;
  n_enabled    int := 0;
  n_skipped    int := 0;
  n_missing    int := 0;
begin
  foreach t in array gated loop
    -- table mojood hai?
    if not exists (
      select 1 from pg_class c
      where c.relname = t
        and c.relnamespace = 'public'::regnamespace
        and c.relkind in ('r','p')
    ) then
      n_missing := n_missing + 1;
      raise notice 'CHHORA (table mojood nahi): %', t;
      continue;
    end if;

    select c.relrowsecurity, c.oid into had_rls, c_oid
    from pg_class c
    where c.relname = t and c.relnamespace = 'public'::regnamespace;

    if had_rls then
      n_skipped := n_skipped + 1;
      raise notice 'PEHLE SE RLS ON: %  (gate pehle hi faal)', t;
      continue;
    end if;

    -- KHAMI THI: agar table par per-officer policies PEHLE SE likhi hui hain
    -- (magar RLS on karna reh gaya), to yahan allow-all lagana un policies ko
    -- hamesha ke liye be-asar kar deta — permissive policies OR hoti hain.
    -- Aisi table insan ka faisla mangti hai, allow-all nahi.
    if exists (select 1 from pg_policy pol
               where pol.polrelid = c_oid and pol.polname <> 'dio_base_all'
                 and pol.polname not like 'dio_sub_%') then
      n_skipped := n_skipped + 1;
      raise warning 'CHHORA: % par pehle se policies hain — RLS khud on karein (40 dekh kar)', t;
      continue;
    end if;

    -- (a) PEHLE permissive allow-all — taake kuch na tootay
    execute format('drop policy if exists dio_base_all on public.%I', t);
    execute format(
      'create policy dio_base_all on public.%I as permissive for all '
      'to authenticated using (true) with check (true)', t);

    -- (b) AB RLS on — restrictive subscription gate yahin jaagti hai
    execute format('alter table public.%I enable row level security', t);

    insert into public.dio_migration_state(script,item) values ('41','rls:'||t)
      on conflict do nothing;
    n_enabled := n_enabled + 1;
    raise notice 'RLS ON kiya: %  (subscription gate ab faal)', t;
  end loop;

  raise notice '──────────────────────────────────────────';
  raise notice 'RLS on kiya: %   pehle se on: %   mojood nahi: %',
               n_enabled, n_skipped, n_missing;
end $$;

-- ── TASDEEQ: ab koi gated table "RLS OFF" nahi honi chahiye ─────
--  (yahi query 40_rls_status_audit.sql me tafseel se hai)
with gated(t) as (
  select unnest(array[
    'cases','case_documents','case_document_versions','case_accused','case_witnesses',
    'suspects','evidence','zimni_reports','zimni_androoni_reports','fir_matn','fir_copies',
    'incident_reports','rfa_forms','cdr_imei_requests','cro_cards','ahkamat',
    'sarkari_gari','hamrahi_mulazman','reminders','court_dates','templates'
  ])
)
select count(*) as "abhi bhi RLS OFF (0 hona chahiye)"
from gated g
join pg_class c
  on c.relname = g.t
 and c.relnamespace = 'public'::regnamespace
 and c.relkind = 'r'
where not c.relrowsecurity;
