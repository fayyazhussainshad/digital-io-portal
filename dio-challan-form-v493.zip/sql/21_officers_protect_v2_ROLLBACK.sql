-- Wapsi: v2 trigger hata kar 20 wala (sirf UPDATE) bahaal karein.
drop trigger  if exists dio_protect_officers_iud on public.officers;
drop function if exists public.dio_protect_officers();
drop index    if exists public.officers_user_id_uidx;
-- 20_officers_protect_trigger.sql dobara chalayein agar purana tahaffuz chahiye.
