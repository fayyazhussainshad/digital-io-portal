-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 21_officers_protect_v2.sql
--  20_officers_protect_trigger.sql ki jaghah/us ke BAAD chalayein.
--
--  20 me ye khamiyan theen:
--   (a) SIRF `before update` — INSERT bilkul khula tha. Afsar apne
--       user_id ke sath aik NAYI row role='superadmin' ke sath daal
--       deta; dio_has_active_sub() `exists(... role='superadmin')`
--       dekhti hai (aik row ka nahi, WUJOOD ka sawal) — yaani mustaqil
--       superadmin ban jata aur har gate se bahar.
--   (b) Koi malkiyat ka check nahi — afsar KISI BHI dusre afsar ki row
--       (naam, thana, CNIC, mobile) badal sakta tha.
--   (c) DELETE par koi trigger nahi — kisi ki bhi row mita sakta tha.
--   (d) `auth.uid() is null` ko "service_role" maan liya gaya tha —
--       halanke anon/kharab JWT par bhi NULL aata hai = bypass.
-- ════════════════════════════════════════════════════════════════

-- Har user ka sirf AIK officer record (exists-check ka bunyadi tahaffuz)
create unique index if not exists officers_user_id_uidx
  on public.officers (user_id) where user_id is not null;

create or replace function public.dio_protect_officers()
returns trigger
language plpgsql
security definer
set search_path = pg_catalog, public, pg_temp
as $$
declare
  v_priv boolean;
begin
  -- service_role (admin panel / Edge Function) — poora ikhtiyar.
  -- NOTE: `auth.uid() is null` par bharosa NAHI (anon par bhi null hota hai).
  if current_user = 'service_role' or coalesce(auth.role(),'') = 'service_role' then
    return case when tg_op = 'DELETE' then old else new end;
  end if;

  -- Ghair-mutaiyan (anon/kharab JWT) — kuch bhi nahi
  if auth.uid() is null then
    raise exception 'ijazat nahi';
  end if;

  select exists (
    select 1 from public.officers o
    where o.user_id = auth.uid()
      and o.role in ('admin','superadmin')
      and coalesce(o.is_suspended,false) = false
      and coalesce(o.is_approved,true)   = true
  ) into v_priv;

  -- ── INSERT ───────────────────────────────────────────────────
  if tg_op = 'INSERT' then
    if not v_priv then
      -- Khud ki registration: sirf apne user_id par, aam afsar, ghair-manzoor
      new.user_id      := auth.uid();
      new.role         := 'officer';
      new.is_approved  := false;
      new.is_suspended := false;
    end if;
    return new;
  end if;

  -- ── DELETE ───────────────────────────────────────────────────
  if tg_op = 'DELETE' then
    if not v_priv then
      raise exception 'afsar ka record sirf admin hata sakta hai';
    end if;
    return old;
  end if;

  -- ── UPDATE ───────────────────────────────────────────────────
  if not v_priv then
    -- Sirf APNI row (pehle kisi ki bhi badal sakte the)
    if old.user_id is distinct from auth.uid() then
      raise exception 'sirf apni profile tabdeel ki ja sakti hai';
    end if;
    -- Hassas column wapas purani qeemat par
    new.role         := old.role;
    new.is_approved  := old.is_approved;
    new.is_suspended := old.is_suspended;
    new.user_id      := old.user_id;
    new.id           := old.id;
  end if;
  return new;
end $$;

revoke all on function public.dio_protect_officers() from public;

drop trigger if exists dio_protect_officer_columns on public.officers;
drop trigger if exists dio_protect_officers_iud    on public.officers;
create trigger dio_protect_officers_iud
  before insert or update or delete on public.officers
  for each row execute function public.dio_protect_officers();

-- ── TASDEEQ ──────────────────────────────────────────────────
select tgname as "trigger",
       case when tgtype & 4  > 0 then 'INSERT ' else '' end ||
       case when tgtype & 16 > 0 then 'UPDATE ' else '' end ||
       case when tgtype & 8  > 0 then 'DELETE'  else '' end as "kis par"
from pg_trigger where tgrelid = 'public.officers'::regclass and not tgisinternal;
