-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 60_subscriptions_lockdown_ROLLBACK.sql
--  KHABARDAR: is ke baad afsar dobara KHUD apni subscription 'active'
--  kar sakega aur poora nafaz be-asar ho jayega. Sirf emergency me.
-- ════════════════════════════════════════════════════════════════
drop policy if exists dio_sub_read_own   on public.subscriptions;
drop policy if exists dio_sub_read_admin on public.subscriptions;
alter table public.subscriptions      disable row level security;
drop policy if exists dio_plans_read on public.subscription_plans;
alter table public.subscription_plans disable row level security;
drop function if exists public.dio_request_subscription(uuid, numeric, text);
drop function if exists public.dio_my_officer_id();
