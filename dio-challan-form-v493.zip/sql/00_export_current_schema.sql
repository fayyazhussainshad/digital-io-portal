-- ============================================================================
-- Digital IO — 00_export_current_schema.sql   (READ-ONLY — kuch nahi badalta)
-- ----------------------------------------------------------------------------
-- Maqsad (Finding 10): DB ka asal schema aur RLS repo se bahar hai. Ye script
-- Supabase SQL Editor me chalayen aur HAR result ko copy kar ke repo me
-- (sql/current_schema/*.txt ya .csv) mehfooz karlen — taake schema+RLS version
-- control me aa jaye aur aainda enforcement bina andaaza (no hallucination) ho.
--
-- Chalane ka tareeqa: Supabase → SQL Editor → naya query → ye poora script
-- paste karen → Run. Har section ka natija alag panel me aayega; sab copy karlen.
-- ============================================================================

-- 1) Tamam tables + columns (public schema)
select table_name, ordinal_position, column_name, data_type, is_nullable, column_default
from information_schema.columns
where table_schema = 'public'
order by table_name, ordinal_position;

-- 2) Har table par RLS on/off (ye SAB SE AHAM hai enforcement se pehle)
select c.relname as table_name,
       c.relrowsecurity  as rls_enabled,
       c.relforcerowsecurity as rls_forced
from pg_class c
where c.relnamespace = 'public'::regnamespace and c.relkind = 'r'
order by c.relname;

-- 3) Maujooda policies (kaun si table par kaun se rules)
select schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
from pg_policies
where schemaname = 'public'
order by tablename, policyname;

-- 4) Functions (RPC / security-definer etc.)
select p.proname as function_name,
       pg_get_function_identity_arguments(p.oid) as args,
       case p.prosecdef when true then 'SECURITY DEFINER' else 'SECURITY INVOKER' end as sec,
       l.lanname as language
from pg_proc p
join pg_language l on l.oid = p.prolang
where p.pronamespace = 'public'::regnamespace
order by p.proname;

-- 5) Triggers
select event_object_table as table_name, trigger_name, action_timing,
       event_manipulation, action_statement
from information_schema.triggers
where trigger_schema = 'public'
order by event_object_table, trigger_name;

-- 6) Foreign keys (rishtay — officers/subscriptions/cases waghera)
select tc.table_name, kcu.column_name,
       ccu.table_name  as ref_table, ccu.column_name as ref_column, tc.constraint_name
from information_schema.table_constraints tc
join information_schema.key_column_usage kcu
  on tc.constraint_name = kcu.constraint_name and tc.table_schema = kcu.table_schema
join information_schema.constraint_column_usage ccu
  on ccu.constraint_name = tc.constraint_name and ccu.table_schema = tc.table_schema
where tc.constraint_type = 'FOREIGN KEY' and tc.table_schema = 'public'
order by tc.table_name, kcu.column_name;

-- 7) Storage buckets (evidence public/private confirm — Finding 4 se marboot)
select id, name, public from storage.buckets order by name;
