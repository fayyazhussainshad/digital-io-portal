-- Digital IO — 20_officers_protect_trigger ko wapas hata deta hai.
drop trigger if exists dio_protect_officer_columns on public.officers;
drop function if exists public.dio_protect_officer_columns();
