-- ============================================================================
-- Digital IO — 10_subscription_enforcement.sql   (Finding 9 ka ASAL hal)
-- ----------------------------------------------------------------------------
-- Masla: subscription ka faisla client (subscription.js) karta hai aur FAIL-OPEN
--        hai — offline ya kisi error par khud 30-din trial de deta hai. Client
--        ka code badal kar muft istemaal mumkin hai.
-- Hal:   Faisla DB par nafiz karo. Miyaad khatam/mualaq = SIRF-PARHNE (view-only).
--        Case content tables par LIKHNA (insert/update/delete) DB rok de, chahe
--        client bypass ho jaye. subscriptions/subscription_plans/officers likhne
--        ke liye khule rahenge (tajdeed + profile). superadmin/admin hamesha allow.
--
-- Rishtay (code se tasdeeq-shuda, no hallucination):
--   officers.user_id       = auth.uid()
--   subscriptions.officer_id = officers.id
--   subscriptions.status  in ('trial','active','suspended','expired')
--   subscriptions.expires_at (timestamptz)
--   officers.role in ('superadmin','admin','officer', ...)
--
-- ⚠️ MEHFOOZ TAREEQA — PEHLE YE PARHEN:
--   • Ye script kisi table par RLS ENABLE NAHI karta. Ye sirf "restrictive"
--     WRITE policies JORTA hai. Restrictive policy sirf US table par asar karti
--     hai jahan RLS PEHLE SE ON hai (yani jahan aap ka per-officer read rule
--     already chal raha hai). Jahan RLS OFF hai, ye policies GHAIR-FAAL rahengi
--     (kuch nahi tootega).
--   • Isi liye pehle 00_export_current_schema.sql chala kar dekh len kaun si
--     table par rls_enabled = true hai. Enforcement sirf unhi par lagega.
--   • Kisi table par RLS khud se ENABLE na karen jab tak us par ek permissive
--     SELECT policy mojood na ho — warna us table ka parhna (read) ruk jayega.
--
-- ROLL BACK: 10_subscription_enforcement_ROLLBACK.sql chala den — sab hat jayega.
-- ============================================================================

-- ── 1) Helper: kya maujooda user ke paas faal subscription hai? ──────────────
create or replace function public.dio_has_active_sub()
returns boolean
language sql
stable
security definer
set search_path = pg_catalog, public, pg_temp
as $$
  select
    -- Maalik/admin par subscription lagoo nahi
    exists (
      select 1 from public.officers o
      where o.user_id = auth.uid()
        and o.role in ('superadmin', 'admin')
    )
    or
    -- Warna: koi bhi faal/trial subscription jis ki miyaad baqi ho
    exists (
      select 1
      from public.officers o
      join public.subscriptions s on s.officer_id = o.id
      where o.user_id = auth.uid()
        and s.status in ('active', 'trial')
        and (case when s.status = 'active' then (s.expires_at is null or s.expires_at > now())
                  else s.expires_at > now() end)
    );
$$;

revoke all on function public.dio_has_active_sub() from public;
grant execute on function public.dio_has_active_sub() to authenticated;

comment on function public.dio_has_active_sub() is
  'Digital IO: true agar maujooda officer ke paas faal/trial (non-expired) subscription ho, ya wo superadmin/admin ho. RLS write-gates isi ko istemaal karti hain.';


-- ── 2) Content tables par WRITE-gate (insert/update/delete) lagao ───────────
--    NOTE: SELECT ko haath nahi lagate — miyaad khatam par bhi parhna chalta
--    rahe (view-only). Sirf likhna rukta hai.
--    Ye list zaroorat ke mutabiq ghatai/barhai ja sakti hai (neeche array).
do $$
declare
  t text;
  gated text[] := array[
    'cases',
    'case_documents',
    'case_document_versions',
    'case_accused',
    'case_witnesses',
    'suspects',
    'evidence',
    'zimni_reports',
    'zimni_androoni_reports',
    'fir_matn',
    'fir_copies',
    'incident_reports',
    'rfa_forms',
    'cdr_imei_requests',
    'cro_cards',
    'ahkamat',
    'sarkari_gari',
    'hamrahi_mulazman',
    'reminders',
    'court_dates',
    'templates'
  ];
begin
  foreach t in array gated loop
    if to_regclass('public.' || t) is null then
      raise notice 'CHHOR DIYA (table mojood nahi): %', t;
      continue;
    end if;

    -- purani (agar dobara chala rahe hain) hata kar dobara banao — idempotent
    execute format('drop policy if exists dio_sub_ins on public.%I', t);
    execute format('drop policy if exists dio_sub_upd on public.%I', t);
    execute format('drop policy if exists dio_sub_del on public.%I', t);

    execute format(
      'create policy dio_sub_ins on public.%I as restrictive for insert to authenticated with check (public.dio_has_active_sub())', t);
    execute format(
      'create policy dio_sub_upd on public.%I as restrictive for update to authenticated using (public.dio_has_active_sub()) with check (public.dio_has_active_sub())', t);
    execute format(
      'create policy dio_sub_del on public.%I as restrictive for delete to authenticated using (public.dio_has_active_sub())', t);

    raise notice 'WRITE-GATE LAGA: %', t;
  end loop;
end $$;


-- ── 3) TASDEEQ (verify) ─────────────────────────────────────────────────────
-- (a) Function chal raha hai?  (superadmin/faal user par true aana chahiye)
--     select public.dio_has_active_sub();
--
-- (b) Kis table par gates lagi?  (dio_sub_ins/upd/del nazar aani chahiye)
--     select tablename, policyname, cmd, permissive
--     from pg_policies
--     where schemaname='public' and policyname like 'dio_sub_%'
--     order by tablename;
--
-- (c) LIVE TEST (ek expired test-officer se): us se cases me insert karke dekhen
--     — DB "new row violates row-level security policy" ke sath rok de, magar
--     select (parhna) chalta rahe. Faal officer se insert kaamyab ho.


-- ============================================================================
-- ⚠️ PEHLI BAAR: PORA script chalane se pehle SIRF EK table par test karen.
--   Sirf neeche wali 4 lines chala kar 'cases' par gate lagayen, phir ek
--   expired aur ek faal officer se likh kar dekhen, phir upar wala poora
--   `do $$ ... $$` block chalayen:
--
--   create policy dio_sub_ins on public.cases as restrictive for insert
--     to authenticated with check (public.dio_has_active_sub());
--   create policy dio_sub_upd on public.cases as restrictive for update
--     to authenticated using (public.dio_has_active_sub()) with check (public.dio_has_active_sub());
--   create policy dio_sub_del on public.cases as restrictive for delete
--     to authenticated using (public.dio_has_active_sub());
-- ============================================================================
