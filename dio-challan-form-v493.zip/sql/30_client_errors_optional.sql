-- ════════════════════════════════════════════════════════════════
--  DIGITAL IO — 30_client_errors_optional.sql   (IKHTIYARI)
--  error-handler.js ke liye. Ye table NA banayein to bhi sab chalta
--  hai — handler khamoshi se sirf device par (localStorage) rakhega.
--
--  DURUSTI: pehle insert policy `with check (true)` thi — yaani koi bhi
--  afsar KISI BHI officer_id ke naam par ghalti darj kar sakta tha
--  (dusre afsar ka record kharab karna). Ab officer_id ko auth.uid()
--  se bandha gaya hai.
-- ════════════════════════════════════════════════════════════════
create table if not exists public.client_errors (
  id         uuid primary key default gen_random_uuid(),
  officer_id uuid references public.officers(id) on delete set null,
  message    text,
  source     text,
  line       int,
  col        int,
  stack      text,
  url        text,
  ua         text,
  at         timestamptz default now(),
  created_at timestamptz default now()
);

-- Lambai ki hadd — flood se bachao
alter table public.client_errors
  drop constraint if exists client_errors_len;
alter table public.client_errors
  add constraint client_errors_len
  check (length(coalesce(message,'')) <= 1000 and length(coalesce(stack,'')) <= 2000);

alter table public.client_errors enable row level security;

-- Sirf APNE naam par likh sakta hai
drop policy if exists client_errors_insert on public.client_errors;
create policy client_errors_insert on public.client_errors
  for insert to authenticated
  -- `= (select ...)` do rows par exception deta tha, aur `is null` shaakh
  -- bina pehchan ke unlimited inserts deti thi. Dono band.
  with check (
    officer_id in (select o.id from public.officers o where o.user_id = auth.uid())
  );

-- Koi SELECT policy nahi → afsar khud parh nahi sakta (sirf service role)
drop policy if exists client_errors_select on public.client_errors;

grant insert on public.client_errors to authenticated;

create index if not exists client_errors_at_idx on public.client_errors (at desc);
