-- ============================================================================
--  WAPSI — 70_no_entry_on_expiry_ROLLBACK.sql
--  Parhne ki rok hata deta hai. Is ke baad system wapas "view-only" par:
--  miyaad khatam par afsar apna record PARH to sakega, likh/chhap nahi.
--  Likhne ki rok (10_subscription_enforcement.sql) apni jagah qaim rehti hai.
-- ============================================================================
do $$
declare
  r record;
begin
  for r in
    select schemaname, tablename
    from pg_policies
    where schemaname = 'public' and policyname = 'dio_sub_sel'
  loop
    execute format('drop policy if exists dio_sub_sel on %I.%I', r.schemaname, r.tablename);
    raise notice 'READ-GATE HATAYA: %', r.tablename;
  end loop;
end $$;
