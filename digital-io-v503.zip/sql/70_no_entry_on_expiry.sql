-- ============================================================================
--  DIGITAL IO — 70_no_entry_on_expiry.sql
--  MAALIK KI HIDAYAT: "Subscription khatam hone ke baad koi IO kisi bhi
--  tarah system me daakhil na ho sake jab tak tajdeed na kare."
--  ---------------------------------------------------------------------------
--  MASLA JO YE THEEK KARTA HAI
--  10_subscription_enforcement.sql sirf LIKHNE (insert/update/delete) par
--  gate lagati hai; PARHNA (select) jaan bujh kar khula chhoRa gaya tha
--  ("view-only"). Natija: client ka tala tor kar — ya seedha API call se —
--  miyaad khatam hone ke baad bhi poora record PARHA ja sakta tha.
--  Client par lagaya hua koi bhi tala is ka jawab nahi, kyunki client afsar
--  ke apne haath mein hai. Asal faisla SERVER par hona chahiye.
--
--  AB: inhi content tables par SELECT bhi `dio_has_active_sub()` se mashroot.
--
--  JAAN BUJH KAR KHULA CHHOR A GAYA (warna afsar hamesha ke liye phans jata):
--    • officers            — apna naam/role/halat parhna (app isi se chalti hai)
--    • subscriptions       — apni halat dekhna (kab khatam hui)
--    • subscription_plans  — plan dekh kar tajdeed karna
--    • audit / error logs  — hifazati record, subscription se alag
--  Maalik/admin par ye kabhi lagu nahi (`dio_has_active_sub()` khud unhe
--  hamesha `true` deta hai).
--
--  WAPSI: 70_no_entry_on_expiry_ROLLBACK.sql chalayen — system wapas
--  "view-only" par aa jayega.
-- ============================================================================

do $$
declare
  t text;
  gated text[] := array[
    'cases',
    'case_documents',
    'case_document_versions',
    'case_accused',
    'case_witnesses',
    'suspects',
    'evidence',
    'zimni_reports',
    'zimni_androoni_reports',
    'fir_matn',
    'fir_copies',
    'incident_reports',
    'rfa_forms',
    'cdr_imei_requests',
    'cro_cards',
    'ahkamat',
    'sarkari_gari',
    'hamrahi_mulazman',
    'reminders',
    'court_dates',
    'templates',
    'applications_5c',
    'application_5c_numbers',
    'application_5c_attachments',
    'officer_transfers'
  ];
begin
  foreach t in array gated loop
    if to_regclass('public.' || t) is null then
      raise notice 'CHHOR DIYA (table mojood nahi): %', t;
      continue;
    end if;

    -- idempotent: dobara chalane par purani policy hata kar nayi
    execute format('drop policy if exists dio_sub_sel on public.%I', t);

    -- RESTRICTIVE: maujooda (permissive) policies ke OOPER aik aur shart.
    -- Yani afsar ko apna record tab hi milta hai jab subscription faal ho.
    execute format(
      'create policy dio_sub_sel on public.%I as restrictive for select to authenticated using (public.dio_has_active_sub())', t);

    raise notice 'READ-GATE LAGA: %', t;
  end loop;
end $$;

-- ── Jaanch: kin tables par ab parhne ki rok hai ─────────────────────────────
select tablename as "table", policyname as "policy", cmd as "amal"
from pg_policies
where schemaname = 'public' and policyname = 'dio_sub_sel'
order by tablename;
