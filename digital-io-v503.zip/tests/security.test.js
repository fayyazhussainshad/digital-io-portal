// ════════════════════════════════════════════════════════════════
//  DIGITAL IO — security smoke tests (Khami 13)
//  Chalayein:  npm test      (node --test, koi bahri library nahi)
//  Ye un hifazati qawaneen ko jaanchte hain jo audit me theek kiye gaye.
// ════════════════════════════════════════════════════════════════
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = path.join(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');

// ── chhota fake browser (localStorage + navigator) ──────────────
function makeSandbox(online = true) {
  const store = new Map();
  const ctx = {
    console,
    navigator: { onLine: online, userAgent: 'test' },
    location: { href: 'http://localhost/' },
    localStorage: {
      getItem: (k) => (store.has(k) ? store.get(k) : null),
      setItem: (k, v) => store.set(k, String(v)),
      removeItem: (k) => store.delete(k),
      clear: () => store.clear(),
    },
    setTimeout, clearTimeout, Date, JSON, Math, String, Number, Object, Array, Promise,
    showToast() {}, _showPlans() {},
    currentOfficer: null, supabaseClient: null,
    async getOfficerId() { return 'OFF-1'; },
  };
  ctx.window = ctx;
  vm.createContext(ctx);
  return ctx;
}

// ─────────────────────────────────────────────────────────────────
test('esc() har khatarnak character ko badalta hai', () => {
  const ctx = makeSandbox();
  vm.runInContext(read('app-core.js').match(/function esc\(s\)[\s\S]*?\n}/)[0], ctx);
  const out = vm.runInContext('esc(`<img src=x onerror="alert(1)">&\'`)', ctx);
  assert.ok(!out.includes('<'), 'koi < nahi bachna chahiye');
  assert.ok(!out.includes('>'), 'koi > nahi bachna chahiye');
  assert.ok(!out.includes('"'), 'koi " nahi bachna chahiye');
  assert.ok(!out.includes("'"), "koi ' nahi bachna chahiye");
  assert.ok(out.includes('&amp;'), '& pehle badalna chahiye');
});

test('_dioJsHtml() inline onclick ke liye quote/backslash rokta hai', () => {
  const ctx = makeSandbox();
  const src = read('app-core.js');
  vm.runInContext(src.match(/function esc\(s\)[\s\S]*?\n}/)[0], ctx);
  vm.runInContext(src.match(/function _dioJsHtml\(s\)[\s\S]*?\n}/)[0], ctx);
  const out = vm.runInContext(`_dioJsHtml("');alert(1);//")`, ctx);
  assert.ok(!out.includes("'"), 'khaam single-quote nahi bachna chahiye');
  assert.ok(!out.includes('"'), 'khaam double-quote nahi bachna chahiye');
});

// ── Khami 9 — offline fail-CLOSED ───────────────────────────────
function loadSubHelpers(ctx) {
  const src = read('subscription.js');
  const start = src.indexOf('const _SUB_CACHE_KEY');
  const end = src.indexOf('// ── SUBSCRIPTION CHECK ON LOGIN');
  assert.ok(start > -1 && end > start, 'fail-closed helpers subscription.js me milne chahiye');
  vm.runInContext(src.slice(start, end), ctx);
}

test('offline + koi cache nahi = MUKHTASIR grace, naya 30-din trial NAHI', async () => {
  const ctx = makeSandbox(false); loadSubHelpers(ctx);
  const r = await vm.runInContext('_dioOfflineStatus("OFF-1")', ctx);
  assert.notStrictEqual(r.daysLeft, 30, 'purana fail-open wapas nahi aana chahiye');
  assert.ok(r.daysLeft <= 3, 'grace 3 din se zyada nahi');
});

test('offline cache guzray dinon ke mutabiq kam hota hai', async () => {
  const ctx = makeSandbox(false); loadSubHelpers(ctx);
  ctx.localStorage.setItem('dio_sub_cache', JSON.stringify(
    { s: 'active', d: 20, p: 'فعال', o: 'OFF-1', t: Date.now() - 5 * 86400000 }));
  const r = await vm.runInContext('_dioOfflineStatus("OFF-1")', ctx);
  assert.strictEqual(r.status, 'active');
  assert.strictEqual(r.daysLeft, 15, '20 - 5 = 15');
});

test('mo\'attal afsar offline ho kar bhi mo\'attal rehta hai', async () => {
  const ctx = makeSandbox(false); loadSubHelpers(ctx);
  ctx.localStorage.setItem('dio_sub_cache', JSON.stringify(
    { s: 'suspended', d: 0, p: 'معطل', o: 'OFF-1', t: Date.now() - 86400000 }));
  const r = await vm.runInContext('_dioOfflineStatus("OFF-1")', ctx);
  assert.strictEqual(r.status, 'suspended', 'internet band kar ke pabandi na tootay');
});

test('miyaad guzar jane par cache expired deta hai', async () => {
  const ctx = makeSandbox(false); loadSubHelpers(ctx);
  ctx.localStorage.setItem('dio_sub_cache', JSON.stringify(
    { s: 'active', d: 5, p: 'فعال', o: 'OFF-1', t: Date.now() - 9 * 86400000 }));
  const r = await vm.runInContext('_dioOfflineStatus("OFF-1")', ctx);
  assert.strictEqual(r.status, 'expired');
});

test('dusre afsar ka cache istemaal nahi hota', async () => {
  const ctx = makeSandbox(false); loadSubHelpers(ctx);
  ctx.localStorage.setItem('dio_sub_cache', JSON.stringify(
    { s: 'active', d: 99, p: 'فعال', o: 'OFF-2', t: Date.now() }));
  const r = await vm.runInContext('_dioOfflineStatus("OFF-1")', ctx);
  assert.ok(r.daysLeft <= 3, 'OFF-2 ka cache OFF-1 ko 99 din na de');
});

// ── Regression guards (khamiyan wapas na aayen) ─────────────────
test('app-core initApp lock PIN ko nahi mitata', () => {
  assert.ok(!/removeItem\(\s*'digital_io_pin_hash'\s*\)/.test(read('app-core.js')),
    'PIN-wipe wapas aa gayi to app-lock (Khami 3) mar jata hai');
});

test('shahadat ke liye koi getPublicUrl baqi nahi', () => {
  for (const f of ['data-api.js', 'cases.js', 'offline-store.js']) {
    assert.ok(!read(f).includes('getPublicUrl'), f + ' me getPublicUrl wapas aa gaya');
  }
});

test('CSP me unsafe-eval nahi', () => {
  assert.ok(!read('vercel.json').includes('unsafe-eval'), 'unsafe-eval wapas nahi aana chahiye');
});

test('naye hifazati module SW precache me hain (offline zaroori)', () => {
  const sw = read('sw.js');
  for (const f of ['secure-storage.js', 'license-token.js', 'error-handler.js']) {
    assert.ok(sw.includes("'/" + f + "'"), f + ' sw.js CORE_ASSETS me hona chahiye');
  }
});

test('index.html admin.js ko sab ke liye load nahi karti', () => {
  assert.ok(!/<script[^>]+src="admin\.js"/.test(read('index.html')),
    'admin.js dobara sab ke liye static load ho gaya (Khami 11)');
});

// ── Mo'attali ka gate (user ka taqaza: mo'attal afsar andar na aaye) ──
test('mo\'attali ka check DURUST column (is_suspended) par hai', () => {
  const a = read('auth.js');
  assert.ok(/_dioIsSuspended/.test(a), 'mushtarik helper mojood hona chahiye');
  assert.ok(/o\.is_suspended === true/.test(a), 'is_suspended dekhna chahiye');
  // purana bug: sirf `currentOfficer.suspended` dekhna (DB column is_suspended hai)
  assert.ok(!/currentOfficer\.suspended === true/.test(a),
    'purana ghalat-column check wapas aa gaya — gate phir mar jayega');
});

test('_dioIsSuspended dono naam aur string shakl pakRta hai', () => {
  const ctx = makeSandbox();
  vm.runInContext(read('auth.js').match(/function _dioIsSuspended[\s\S]*?\n}/)[0], ctx);
  const f = (o) => vm.runInContext('_dioIsSuspended(' + JSON.stringify(o) + ')', ctx);
  assert.strictEqual(f({ is_suspended: true }), true);
  assert.strictEqual(f({ is_suspended: 'true' }), true);
  assert.strictEqual(f({ suspended: true }), true);          // purane record
  assert.strictEqual(f({ is_suspended: false }), false);
  assert.strictEqual(f({}), false);
  assert.strictEqual(f(null), false);
});

test('offline raasta bhi mo\'attal afsar ko rokta hai', () => {
  const a = read('auth.js');
  const fn = a.slice(a.indexOf('async function _dioOfflineRestore'),
                     a.indexOf('window._dioOfflineRestore'));
  assert.ok(/_dioIsSuspended\(officer\)/.test(fn),
    'offline restore me mo\'attali check hona chahiye warna internet band kar ke bypass');
  assert.ok(/_dioPurgeOnSuspend/.test(fn), 'cached session saaf honi chahiye');
});

test('suspended par daakhla band, magar expired par view-only barqarar (4E)', () => {
  const s = read('subscription.js');
  assert.ok(/sub\.status === 'suspended'/.test(s), 'suspended par daakhla rukna chahiye');
  assert.ok(/showSubscriptionRequired\(sub\)/.test(s), 'tajdeed ka safha dikhna chahiye');
  // 4E ka faisla: expired par poora lock NA ho
  assert.ok(!/sub\.status === 'expired'[\s\S]{0,80}showSubscriptionRequired/.test(s),
    'expired par poora lock 4E ke faisle ke khilaf hai');
});

test('SQL write-gate mo\'attali aur manzoori dono dekhti hai', () => {
  const g = read('sql/50_suspend_hard_gate.sql');
  assert.ok(/is_suspended/.test(g), 'is_suspended check zaroori');
  assert.ok(/is_approved/.test(g), 'is_approved check zaroori');
  assert.ok(/role = 'superadmin'/.test(g), 'maalik mustasna rehna chahiye');
  // purana masla: admin ko poora mustasna kar dena
  assert.ok(!/role in \('superadmin', 'admin'\)/.test(g),
    'admin ko poora mustasna karna = mo\'attal admin likh sakega');
});

// ── Jaiza-2 me mile masail (regression guards) ──────────────────
test('IndexedDB: auth.js aur secure-storage.js alag DB — store takraao nahi', () => {
  const a = read('auth.js'), ss = read('secure-storage.js');
  const dbA = (a.match(/indexedDB\.open\('([^']+)'/) || [])[1];
  const dbS = (ss.match(/var DB = '([^']+)'/) || [])[1];
  assert.ok(dbA && dbS, 'dono DB naam milne chahiyen');
  assert.notStrictEqual(dbA, dbS,
    'aik hi DB + alag store = aik encryption layer khamoshi se mar jati hai');
});

test('token/PIN login bhi mo\'attali gate se guzarta hai', () => {
  const a = read('auth.js');
  const fn = a.slice(a.indexOf('async function _dioLoginWithToken'),
                     a.indexOf('async function _dioOfflineRestore'));
  assert.ok(/_dioIsSuspended/.test(fn), 'PIN/biometric raasta gate ke baghair tha');
  assert.ok(/_dioNotApproved/.test(fn), 'manzoori bhi yahin check honi chahiye');
});

test('offline restore officer snapshot na ho to andar na aane de', () => {
  const a = read('auth.js');
  const fn = a.slice(a.indexOf('async function _dioOfflineRestore'), a.indexOf('window._dioOfflineRestore'));
  assert.ok(/if \(!officer\)[\s\S]{0,120}return false/.test(fn),
    'officer cache mita kar bypass mumkin tha — fail-closed hona chahiye');
  assert.ok(!/role: 'officer' \}/.test(fn), 'saaf default officer banana bypass deta hai');
});

test('mo\'attal afsar par write-guard ka flag zabardasti lagta hai', () => {
  const s = read('subscription.js');
  assert.ok(/DIO\.sub\._blocked = true/.test(s),
    'sirf div badalna kaafi nahi tha — print/write khule reh jate the');
});

test('offline cache bina officer-binding ke qabool na ho', () => {
  const ctx = makeSandbox(false);
  const src = read('subscription.js');
  vm.runInContext(src.slice(src.indexOf('const _SUB_CACHE_KEY'),
                            src.indexOf('// ── SUBSCRIPTION CHECK ON LOGIN')), ctx);
  // `o` field hata kar har afsar par lagane ki koshish
  ctx.localStorage.setItem('dio_sub_cache', JSON.stringify({ s:'active', d:99999, p:'x', t:Date.now() }));
  const r = vm.runInContext('_dioReadSubCache("OFF-1")', ctx);
  assert.strictEqual(r, null, 'bina `o` wala cache qabool nahi hona chahiye');
});

test('ghari peeche karne se miyaad na baRhe', () => {
  const ctx = makeSandbox(false);
  const src = read('subscription.js');
  vm.runInContext(src.slice(src.indexOf('const _SUB_CACHE_KEY'),
                            src.indexOf('// ── SUBSCRIPTION CHECK ON LOGIN')), ctx);
  ctx.localStorage.setItem('dio_hw_clock', String(Date.now()));          // asli waqt yaad
  ctx.localStorage.setItem('dio_sub_cache', JSON.stringify(
    { s:'active', d:10, p:'x', o:'OFF-1', t: Date.now() - 5*86400000 }));
  const r = vm.runInContext('_dioReadSubCache("OFF-1")', ctx);
  assert.ok(r.daysLeft <= 5, 'cache 10 din, 5 guzre → 5 se zyada na mile, mila: ' + r.daysLeft);
});

test('admin panel durust column (is_suspended) dekhta hai', () => {
  const a = read('admin.js');
  assert.ok(!/[^_.]\bo\.suspended\b/.test(a.replace(/o\.is_suspended \|\| o\.suspended/g, '')),
    'admin.js me bhi wahi column bug tha — mo\'attal afsar nazar hi nahi aata tha');
});

test('mo\'attali ke columns client denylist me hain', () => {
  const d = read('data-api.js');
  for (const c of ['is_suspended', 'suspension_reason'])
    assert.ok(d.includes("'" + c + "'"), c + ' _OFFICER_PROTECTED me hona chahiye');
});

test('sanitizer https/mailto/blob nahi kaatta, javascript: kaatta hai', () => {
  const m = read('dio-html.js').match(/ALLOWED_URI_REGEXP: (\/.*\/i),/);
  assert.ok(m, 'regexp milna chahiye');
  const re = eval(m[1]);
  for (const u of ['https://x.co/a.png', 'http://x.co', 'mailto:a@b.c', 'blob:x', '/rel.png'])
    assert.ok(re.test(u), u + ' kaatna nahi chahiye (tasveerain/link tootte hain)');
  for (const u of ['javascript:alert(1)', 'vbscript:x'])
    assert.ok(!re.test(u), u + ' rukna chahiye');
});

test('zimni print picker button poora hataata hai (awara ▾ na aaye)', () => {
  const z = read('zimni.js');
  assert.ok(/_zimniSafePrint/.test(z), 'print helper hona chahiye');
  assert.ok(/<button\\b\[\^>\]\*>\[\\s\\S\]\*\?<\\\/button>/.test(z) || /button\\b/.test(z),
    'button poora (text samet) nikalna chahiye, warna adaalati kaghaz par ▾ chhapta hai');
});

test('error log nijji maloomat redact karta hai', () => {
  const src = read('error-handler.js');
  const ctx = makeSandbox();
  vm.runInContext(src.match(/function _redact\(t\) \{[\s\S]*?\n  \}/)[0], ctx);
  const out = vm.runInContext(
    '_redact("fail 35202-1234567-1 / 03001234567 / a@b.com / password: hunter2")', ctx);
  for (const bad of ['35202-1234567-1', '03001234567', 'a@b.com', 'hunter2'])
    assert.ok(!out.includes(bad), bad + ' log me nahi jana chahiye');
});

test('client_errors dusre afsar ke naam par darj na ho sake', () => {
  // Tabsare (-- ...) hata kar sirf ASAL SQL jaanchein — warna purane
  // code ka zikr karne wala comment hi test fail kar deta hai.
  const g = read('sql/30_client_errors_optional.sql')
    .split('\n').filter((l) => !l.trim().startsWith('--')).join('\n');
  assert.ok(!/with check \(\s*true\s*\)/.test(g), 'with check(true) = kisi bhi officer_id par likh do');
  assert.ok(/auth\.uid\(\)/.test(g), 'officer_id auth.uid() se bandha hona chahiye');
});

test('debug banner innerHTML istemaal nahi karta', () => {
  assert.ok(!/b\.innerHTML \+=/.test(read('index.html')),
    'error banner me innerHTML = DOM XSS ka raasta');
});

// ══ Round-3: nazam ki gehri khamiyan ═══════════════════════════
test('subscriptions client whitelist se nikali gayi (gate ki apni table)', () => {
  const s = read('subscription.js');
  const m = s.match(/_DIO_WRITE_WL = \{([^}]*)\}/);
  assert.ok(m, 'whitelist milni chahiye');
  assert.ok(!/\bsubscriptions\b/.test(m[1]),
    'gate ka faisla subscriptions se hota hai — wahi table khuli rakhna poora nafaz khatam kar deta hai');
});

test('subscriptions DB par bhi lock hai aur tajdeed RPC se hoti hai', () => {
  const g = read('sql/60_subscriptions_lockdown.sql');
  assert.ok(/alter table public\.subscriptions enable row level security/.test(g));
  assert.ok(/dio_request_subscription/.test(g), 'tajdeed ka mehfooz raasta hona chahiye');
  assert.ok(!/create policy[\s\S]{0,200}for (insert|update|delete) to authenticated/.test(g),
    'authenticated ke liye koi write policy nahi honi chahiye');
});

test('officers trigger INSERT + DELETE bhi cover karta hai', () => {
  const g = read('sql/21_officers_protect_v2.sql');
  assert.ok(/before insert or update or delete/.test(g),
    'sirf UPDATE par trigger = INSERT se superadmin ban jana mumkin');
  assert.ok(/officers_user_id_uidx/.test(g), 'har user ka aik hi record (exists-check ka tahaffuz)');
  assert.ok(/sirf apni profile/.test(g), 'dusre afsar ki row mehfooz honi chahiye');
});

test('50: is_approved NULL par fail-CLOSED', () => {
  const g = read('sql/50_suspend_hard_gate.sql');
  assert.ok(/coalesce\(o\.is_approved,\s*false\)/.test(g),
    'coalesce(..., true) = NULL wala afsar manzoor maan liya jata');
});

test('active + NULL miyaad par lockout na ho', () => {
  for (const f of ['sql/50_suspend_hard_gate.sql', 'sql/10_subscription_enforcement.sql'])
    assert.ok(/expires_at is null or s\.expires_at > now\(\)/.test(read(f)),
      f + ': NULL miyaad par asli paying afsar block ho jata tha');
});

test('41 rollback sirf apne enable kiye tables par chalta hai', () => {
  const g = read('sql/41_rls_enable_safe_ROLLBACK.sql');
  assert.ok(/dio_migration_state/.test(g),
    'bina record ke rollback un tables ki RLS bhi band kar deta jo pehle se mehfooz theen');
});

test('41 un tables ko chhoRta hai jin par pehle se policies hain', () => {
  const g = read('sql/41_rls_enable_safe.sql');
  assert.ok(/pg_policy[\s\S]{0,200}raise warning/.test(g),
    'dormant per-officer policies par allow-all lagana unhein hamesha be-asar kar deta');
});

test("status 'none' bhi block kare (fail-closed)", () => {
  const s = read('subscription.js');
  assert.ok(/status === 'none'/.test(s),
    "'none' par guard band ho jata tha — cache mita kar offline jana kaafi tha");
});

test('grace khud-tajdeed na ho (aik hi baar)', () => {
  const s = read('subscription.js');
  assert.ok(/dio_grace_start/.test(s), 'grace ka aaghaz mehfooz hona chahiye');
  assert.ok(/localStorage\.removeItem\('dio_grace_start'\)/.test(s),
    'kamyab online tasdeeq par grace reset hona chahiye');
});

test('license token officer se BANDHA ho (fail-closed)', () => {
  const s = read('subscription.js');
  assert.ok(/!\(oid && lic\.officerId && lic\.officerId === oid\)/.test(s),
    'short-circuit se dusre afsar ka token qabool ho jata tha');
});

test('storage aur rpc bhi write-guard me hain', () => {
  const s = read('subscription.js');
  assert.ok(/storage\.from = function/.test(s),
    'storage.from khula tha — mo\'attal afsar files upload karta rehta');
  assert.ok(/supabaseClient\.rpc = function/.test(s), 'rpc bhi guard me hona chahiye');
});

test('write-guard fauran lagta hai (3 second ka window nahi)', () => {
  const s = read('subscription.js');
  assert.ok(/try \{ _installDioWriteGuard\(\); \} catch/.test(s),
    'sirf setTimeout(...,3000) = shuru ke 3 second me har write bila rok');
});

test('SW navigate apni key par cache kare (poisoning nahi)', () => {
  const g = read('sw.js');
  assert.ok(/cache\.put\(event\.request, clone\)/.test(g),
    "har navigation ka jawab '/index.html' par likhna = app ka shell badal jata");
  assert.ok(/navUrl\.origin !== self\.location\.origin/.test(g), 'bahar ke safhe chhoRne chahiyen');
});

test('offline queue mustaqil ghalti par rukti hai aur ittila deti hai', () => {
  const g = read('offline-store.js');
  assert.ok(/status === 'failed'|'failed'/.test(g), 'mustaqil nakaami alag honi chahiye');
  assert.ok(/attempts >= 5/.test(g), 'koshishon ki hadd honi chahiye');
  assert.ok(/getFailed/.test(g), 'afsar ko rad-shuda andraaj dikhne chahiyen');
});

test('edge function mo\'attali/manzoori jaanchta hai aur admin bila-shart nahi', () => {
  const g = read('supabase/functions/dio-license/index.ts');
  assert.ok(/is_suspended, is_approved/.test(g), 'sirf id,role parhna = mo\'attal ko token mil jata');
  assert.ok(/error: "not_entitled"/.test(g), 'bila-haq par dastkhat nahi hona chahiye');
  assert.ok(/const isOwner\s*=\s*officer\.role === "superadmin"/.test(g),
    'admin ko superadmin ke sath mustasna karna wahi purani khami thi');
  assert.ok(!/String\(e && \(e as Error\)\.message/.test(g), 'andarooni ghalti bahar na jaye');
});

// ══ MOBILE + RAFTAAR (round-4) ═════════════════════════════════
test('mobile ki files jur gayi hain (html + service worker)', () => {
  const h = read('index.html');
  for (const f of ['mobile.css', 'mobile.js', 'boot.js'])
    assert.ok(h.includes(f), f + ' index.html me honi chahiye');
  const sw = read('sw.js');
  for (const f of ['mobile.css', 'mobile.js', 'boot.js'])
    assert.ok(sw.includes("'/" + f + "'"), f + ' sw precache me — warna offline par nahi milegi');
});

test('form mode kaghaz ki paki chauRai khatam karta hai', () => {
  const c = read('mobile.css');
  assert.ok(/html\.dio-mform #ch173-doc[\s\S]{0,200}width:\s*100%/.test(c),
    'A4 ki 8.5in chauRai fon par 2.18x overflow deti thi');
  assert.ok(/tr\.zf-blk/.test(c), 'har andraaj card banna chahiye');
});

test('CHHAPAI par mobile ka koi asar na ho (kaghaz A4/Legal rahe)', () => {
  const c = read('mobile.css');
  // Ab file me AIK se ZYADA @media print block hain (zimni + challan form).
  // `lastIndexOf` aakhri wala pakaR leta tha — is liye SAB print blocks jorte hain.
  const printBlock = c.split('@media print').slice(1).join('\n@media print');
  for (const [sel, val] of [['table\\.zf-tbl', 'display: table'],
                            ['tbody', 'display: table-row-group'],
                            ['tr', 'display: table-row'],
                            ['td', 'display: table-cell']])
    assert.ok(new RegExp(sel + '[\\s\\S]{0,160}' + val).test(printBlock),
      'print me ' + sel + ' wapas ' + val + ' hona chahiye');
  assert.ok(/td::before\s*\{\s*content:\s*none/.test(printBlock),
    'mobile ke unwan kaghaz par nahi chhapne chahiyen');
  assert.ok(/\.dio-mbar,\s*\.dio-addblk,\s*\.dio-thumbbar\s*\{\s*display:\s*none/.test(printBlock),
    'mobile ke button kaghaz par nahi aane chahiyen');
});

test('form mode me koi DOM node hilayi nahi jati (save/print mehfooz)', () => {
  const j = read('mobile.js');
  assert.ok(!/appendChild\(\s*(body|cell|td|tr)\b/.test(j),
    'dastavez ke node hilana save ke waqt content gum kar sakta hai');
  assert.ok(/classList\.toggle\('dio-mform'/.test(j), 'sirf class lagni chahiye');
});

test('boot.js window._pages par inhesar na kare', () => {
  // Tabsare hata kar sirf ASAL code jaancho — warna khami ka zikr
  // karne wala comment hi test fail kar deta hai.
  const j = read('boot.js')
    .split('\n').filter((l) => !l.trim().startsWith('//')).join('\n');
  assert.ok(!/window\._pages/.test(j),
    'app-core me `const _pages` hai — window par aata hi nahi, is liye har safha lazy ban jata tha');
  assert.ok(/loadedAlready/.test(j), 'script mojood hai ya nahi — yahi mehfooz sawal hai');
});

test('bhaari module blocking list se nikal gaye', () => {
  const h = read('index.html');
  for (const f of ['zimni.js', 'report173.js', 'naqsha-mauqa.js', 'saza-slip.js', 'templates.js'])
    assert.ok(!new RegExp('<script defer src="' + f.replace('.', '\\.') + '"').test(h),
      f + ' abhi bhi DOMContentLoaded rok raha hai');
  const bt = read('boot.js');
  for (const f of ['zimni.js', 'report173.js'])
    assert.ok(bt.includes("'" + f + "'"), f + ' boot.js ki fursat-list me hona chahiye');
});

test('har lazy safhe ki file boot.js ke naqshe me hai', () => {
  const bt = read('boot.js');
  const map = bt.slice(bt.indexOf('var PAGE_SRC'), bt.indexOf('function ensurePage'));
  const files = [...map.matchAll(/'([a-z0-9-]+\.js)'/g)].map(m => m[1]);
  assert.ok(files.length >= 10, 'kam az kam 10 safhe lazy hone chahiyen, mile: ' + files.length);
  // NOTE: deliver kiya gaya ZIP me sirf BADLI hui files hoti hain, is liye
  // yahan wahi jaanchte hain jo mojood hain. Poore repo me (deploy ke baad)
  // ye check har file par lagta hai — lazy file ka 404 = safha hi na khule.
  let checked = 0;
  for (const f of files) {
    if (!fs.existsSync(path.join(ROOT, f))) continue;   // package me nahi — repo me hai
    checked++;
    assert.ok(fs.statSync(path.join(ROOT, f)).size > 0, f + ' khali hai');
  }
  assert.ok(checked >= 8, 'kam az kam 8 lazy files jaanchi jani chahiyen, jaanchi: ' + checked);
});

// ══ CHALLAN KA MOBILE FORM (round-5) ═══════════════════════════
test('zimni ka form-mode CSS SIRF .zf-editor par (challan mehfooz)', () => {
  // Block comment POORA nikalo — warna comment mein likhi wazahat
  // (jo khud is qaide ki yaad-dihani hai) test ko toR deti hai.
  const c = read('mobile.css').replace(/\/\*[\s\S]*?\*\//g, '');
  const bad = c.split('\n').filter((l) => /#ch173-doc(?!\.zf-editor)/.test(l));
  assert.strictEqual(bad.length, 0,
    'zimni aur challan ka id AIK hi (ch173-doc) hai — bina .zf-editor ke qaida challan par bhi lagta hai, ' +
    'aur `width:100% !important` `_printR173` ki inline 8.5in naap ko HARA deta hai. Mile: ' + bad.join(' | '));
});

test('challan ke apne khane (amoodi likhayi) CSS se chhue na jayen', () => {
  const c = read('mobile.css');
  for (const sel of ['.rotinner', '.rotclip', '.cellbox', '.normwrap', '.ch173-table'])
    assert.ok(!new RegExp('\\' + sel + '\\s*[,{]').test(c),
      sel + ' ko mobile.css chhu rahi hai — challan ki px-naap toot sakti hai');
});

test('challan form kaghaz ko display:none se NAHI chhupata', () => {
  const j = read('challan-form.js');
  const fn = j.slice(j.indexOf('function show(formOn)'), j.indexOf('function restoreForPrint'));
  assert.ok(/style\.height = '0'/.test(fn), 'collapse height:0 se hona chahiye');
  assert.ok(!/style\.display\s*=\s*'none'/.test(fn),
    "display:none se element ki naap 0 ho jati hai — `_printR173` ki chhapai toot jati hai");
});

test('challan form asal [data-k] node me likhta hai (save/print wahi parhte hain)', () => {
  const j = read('challan-form.js');
  assert.ok(/node\.innerHTML = el\.innerHTML/.test(j),
    'form ko asal document ke khane me likhna chahiye, warna save me kuch na jata');
  assert.ok(!/appendChild\(node\)|insertBefore\(node/.test(j),
    'dastavez ke node hilana save ke waqt content gum kar sakta hai');
});

test('chhapai par kaghaz wapas khulta hai (hawale se, parent se nahi)', () => {
  const j = read('challan-form.js');
  assert.ok(/window\.addEventListener\('beforeprint'/.test(j), 'beforeprint par bahaal hona chahiye');
  const fn = j.slice(j.indexOf('function restoreForPrint'), j.indexOf("window.addEventListener('beforeprint'"));
  assert.ok(/_wrapEl/.test(fn) && !/doc\.parentElement/.test(fn),
    'beforeprint par app dastavez ko #dio-nprint-host me le jati hai — parentElement us waqt GHALAT dabba deta hai');
});

test('challan form ka intikhab yaad rehta hai', () => {
  const j = read('challan-form.js');
  assert.ok(/dio_challan_view/.test(j), 'afsar ka intikhab mehfooz hona chahiye');
  assert.ok(/show\(wantForm\(\)\)/.test(j),
    'refresh har baar zabardasti form na khole — warna "کاغذ" chunna bekaar ho jata hai');
});

test('challan-form.js jur gayi (html + sw)', () => {
  assert.ok(read('index.html').includes('challan-form.js'));
  assert.ok(read('sw.js').includes("'/challan-form.js'"), 'offline par bhi milni chahiye');
});

// ══ PESHA-WARANA SHAKL (round-6) ═══════════════════════════════
test('login ki hifazati satar ka BIDI masla band', () => {
  const h = read('index.html');
  const i = h.indexOf('256-bit AES Encrypted');
  assert.ok(i > -1, 'satar mojood honi chahiye');
  const around = h.slice(Math.max(0, i - 260), i);
  assert.ok(/dir="ltr"/.test(around) && /unicode-bidi:\s*isolate/.test(around),
    'RTL khane me angrezi satar toot kar "bit … -256" ban jati thi — dir=ltr + isolate lazmi');
});

test('login ke asal button me emoji nahi', () => {
  const h = read('index.html');
  const seg = h.slice(h.indexOf('id="login-submit-btn"'), h.indexOf('id="login-submit-btn"') + 300);
  assert.ok(!/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(seg), 'CTA me emoji ghair-pesha-warana lagta hai');
  assert.ok(/محفوظ لاگ اِن/.test(seg), 'CTA Urdu me hona chahiye (app Urdu-first hai)');
});

test('dashboard se sawal aur nukta hat gaye, AYAT barqarar', () => {
  const d = read('dashboard.js');
  assert.ok(!/\$\{_dashKnowledgeCard\(\)\}/.test(d), 'sawal ka card hat jana chahiye');
  assert.ok(!/\$\{_dashTipOfDay\(\)\}/.test(d), 'nukta ka card hat jana chahiye');
  assert.ok(!/initQARotation\(\)/.test(d), 'uska timer bhi band hona chahiye');
  assert.ok(/_islamicBarHTML\(\)/.test(d), 'Qurani ayat BARQARAR rehni chahiye (afsar ki hidayat)');
});

test('dashboard par koi gehra gradient card nahi bacha', () => {
  const d = read('dashboard.js');
  const bad = (d.match(/background:\s*linear-gradient\(135deg,#[0-9a-f]{6},#[0-9a-f]{6}\)/gi) || []);
  assert.strictEqual(bad.length, 0,
    'aik hi sakreen par kai gehre gradient "sasta" tasur dete the. Mile: ' + bad.join(', '));
});

test('adad HERO hain — un ke element blanket font-size qaide se BAHAR', () => {
  const d = read('dashboard.js');
  // index.html ka qaida `:is(div,span,p,td,th,li,label,a)` par 14px !important
  // thonkta hai (10 `:not(#id)` ki wajah se us ko haraya nahi ja sakta).
  assert.ok(/<b class="dio-stat-num">/.test(d), 'stat ka adad <b> me hona chahiye, span me nahi');
  assert.ok(/<b class="dio-prio-num">/.test(d), 'tarjeeh ka adad <b> me hona chahiye');
  assert.ok(/<b class="dio-sec-h"[^>]*role="heading"/.test(d),
    'unwan <h2> par `font-size: revert` lag jata hai — <b role=heading> chahiye');
  const c = read('theme-pro.css');
  assert.ok(/b\.dio-stat-num\s*\{[^}]*font-size:\s*30px/.test(c), 'adad numayan (30px) hona chahiye');
});

test('theme-pro.css jur gayi (html + sw)', () => {
  assert.ok(read('index.html').includes('theme-pro.css'));
  assert.ok(read('sw.js').includes("'/theme-pro.css'"), 'offline par bhi milni chahiye');
});

/* ═══════════════════════════════════════════════════════════════
   ROUND 4 — Topbar aur baqi safhon ka peshawarana look
   ═══════════════════════════════════════════════════════════════ */

test('topbar me #topbar-title MOJOOD hai (do cheezen is par chalti hain)', () => {
  const h = read('index.html');
  assert.ok(/id="topbar-title"/.test(h),
    'app-core.js is me safhe ka naam likhta hai AUR setupRealtimeSync isi ke ' +
    'matn se faisla karta hai ke mocaddmat/yaad-dihaniyan khuli hain ya nahi. ' +
    'Ise hatane se afsar ko safhe ka naam nazar nahi aata aur live refresh band ho jata hai.');
  const a = read('app-core.js');
  assert.ok(/getElementById\('topbar-title'\)/.test(a), 'app-core isi id par likhta hai');
});

test('chhoti sakreen par safhe ka naam rehta hai, wordmark chhupta hai', () => {
  const c = read('theme-pro.css');
  const m = c.match(/@media \(max-width: 760px\) \{[\s\S]*?\n\}/);
  assert.ok(m, '760px ka media block mojood ho');
  assert.ok(/\.dio-tb-name\s*\{\s*display:\s*none/.test(m[0]),
    'tang jagah par wordmark chhupe — safhe ka naam zyada zaroori hai');
  assert.ok(!/\.dio-tb-sub\s*\{\s*display:\s*none/.test(m[0]),
    'safhe ka naam (#topbar-title) kabhi na chhupe');
});

test('.card-title Urdu ke liye parha ja sakta hai', () => {
  const c = read('theme-pro.css');
  const m = c.match(/\.card-title,\s*\.section-title\s*\{[\s\S]*?\}/);
  assert.ok(m, '.card-title ka qaida mojood ho');
  assert.ok(/text-transform:\s*none/.test(m[0]),
    'uppercase ne "OFFICER INFORMATION CONTACT ADMIN TO UPDATE" bana diya tha');
  assert.ok(/letter-spacing:\s*0/.test(m[0]), 'letter-spacing Urdu ke jurey huroof toRta hai');
  assert.ok(/font-size:\s*13px/.test(m[0]), '10px par Nastaleeq parhi nahi jati');
});

test('settings ka "تعیناتی محفوظ کریں" button toota hua nahi', () => {
  const s = read('settings.js');
  assert.ok(!/getElementById\('set-official-phone'\)\.value/.test(s),
    'ye khana markup me MOJOOD NAHI — seedha .value lene par TypeError aata tha ' +
    'aur poora save button kaam karna chhoR deta tha');
  assert.ok(/const _v = id =>/.test(s), 'mehfooz helper se padha jaye');
});

test('court aur reminders ke header ka <div> theek band hota hai', () => {
  for (const f of ['court.js', 'reminders.js']) {
    const s = read(f);
    assert.ok(!/direction:rtl;"><div style="display:flex;align-items:center;gap:10px;"/.test(s),
      f + ': do <div> khulte the magar aik band hota tha — poora safha header ki ' +
      'flex row me chala jata tha');
    assert.ok(/<div class="page-header"/.test(f === 'court.js' ? s : s), f + ': saaf header ho');
  }
});

test('safha-sazi me emoji nahi bache (dastavez wali files mustasna)', () => {
  const EMO = /[⌚-⏺☀-➿⬀-⯿\u{1F000}-\u{1FAFF}]/u;
  const pages = ['settings.js', 'court.js', 'reminders.js', 'suspects.js',
                 'cases.js', 'templates.js', 'law-library.js', 'bin.js'];
  const bad = [];
  for (const f of pages) {
    read(f).split('\n').forEach((l, i) => { if (EMO.test(l)) bad.push(f + ':' + (i + 1)); });
  }
  assert.strictEqual(bad.length, 0, 'emoji har device par alag dikhte hain. Mile: ' + bad.slice(0, 8).join(', '));
});

test('nishan wale button khali nahi — SVG + aria-label', () => {
  for (const f of ['cases.js', 'templates.js', 'law-library.js', 'fivec.js']) {
    const s = read(f);
    const empty = s.match(/<button\b(?:[^<>]|<(?!\/?button))*?>\s*<\/button>/g) || [];
    assert.strictEqual(empty.length, 0, f + ': khali button mila');
    assert.ok(/aria-label="/.test(s), f + ': nishan wale button par aria-label chahiye');
  }
});

test('dio-states ke nishan SVG hain aur icon bahar se nahi aata', () => {
  const s = read('dio-states.js');
  assert.ok(/var ICON_PATHS = \{/.test(s), 'nishan ka daftar mojood ho');
  assert.ok(!/\+ _esc\(icon\) \+/.test(s),
    'icon ab matn nahi — daftar se aata hai, is liye bahar ka HTML yahan nahi pahunchta');
  assert.ok(/_icon\(icon, 44\)/.test(s), 'empty() daftar hi se nishan le');
  assert.ok(/width:100%/.test(s), 'khali-halat ka dabba poori chauRai le — warna markaz me nahi aata');
});

test('SW ka version bump hua (qaida: har tabdeeli par lazmi)', () => {
  const sw = read('sw.js');
  const m = sw.match(/const CACHE_NAME = 'digital-io-v(\d+)'/);
  assert.ok(m, 'CACHE_NAME mojood ho');
  assert.ok(Number(m[1]) >= 495, 'v495 ya us se aage hona chahiye, mila: v' + m[1]);
  assert.ok(sw.includes('SERVICE WORKER v' + m[1]), 'header ka comment bhi wahi version dikhaye');
});

test('FIR/CNIC jaise angrezi adad LTR khane me hain (RTL me ulat jate the)', () => {
  const c = read('cases.js');
  assert.ok(/unicode-bidi:isolate/.test(c),
    'RTL me "205/2025" ulta "2025/205" parha jata tha — isolate zaroori hai');
});

/* ═══════════════════════════════════════════════════════════════
   ROUND 5 — Afsar ke bataye huay 5 nuqat
   ═══════════════════════════════════════════════════════════════ */

test('1) "واپس" har jagah AIK hi shakl aur AIK hi taraf', () => {
  const h = read('index.html');
  assert.ok(/id="dio-back-btn"[\s\S]{0,400}class="topnav-btn dio-backbtn"|class="topnav-btn dio-backbtn"[\s\S]{0,200}id="dio-back-btn"/.test(h)
            || /id="dio-back-btn" class="topnav-btn dio-backbtn"/.test(h),
    'topbar ka button `dio-backbtn` class istemal kare');
  assert.ok(!/margin-right:auto[^"]*"[^>]*id="dio-back-btn"|id="dio-back-btn"[^>]*margin-right:auto/.test(h),
    'purana `margin-right:auto` (baain kona) na bacha ho');
  assert.ok(/<span>واپس<\/span>/.test(h), 'sirf teer nahi — lafz "واپس" bhi ho');
  // dono overlay bhi wahi class istemal karen
  for (const f of ['doc-viewer.js', 'misal-docs.js']) {
    const s = read(f);
    assert.ok(/class="dio-backbtn"/.test(s), f + ': wahi class ho');
    assert.ok(!/font-size:18px;font-weight:900;line-height:1;direction:ltr;">←</.test(s),
      f + ': purana gol "←" wala button na bacha ho');
  }
  const c = read('theme-pro.css');
  assert.ok(/\.dio-backbtn\s*\{/.test(c), 'shakl aik hi jagah se aaye');
});

test('2) mic — desktop par sust hone ki teeno wajuhat khatam', () => {
  const m = read('global-mic.js');
  assert.ok(/recog\.interimResults = true/.test(m),
    'adhoora matn foran dikhe — warna afsar ko lagta hai mic chal hi nahi raha');
  assert.ok(/id="global-mic-live"|'global-mic-live'/.test(m), 'sunta hua matn dikhane wali patti ho');
  // onend par khud-ba-khud dobara chale
  assert.ok(/if \(!wantOn\) \{ setBtn\(false\); say\(''\); return; \}/.test(m),
    'sirf afsar ke band karne par ruke');
  assert.ok(/setTimeout\(function \(\) \{ if \(wantOn\) spin\(\); \}, 180\);/.test(m),
    'Chrome khud session band kare to chupke se dobara chale');
  // waqti ghalti par band na ho
  assert.ok(/code === 'not-allowed' \|\| code === 'service-not-allowed'/.test(m),
    'sirf ijazat waali ghalti par band ho, no-speech/network par nahi');
  assert.ok(/restarts > 5/.test(m), 'pe-dar-pe nakami par toofan se bachao ho');
  // PAKKA matn hi dastavez mein
  assert.ok(/if \(e\.results\[i\]\.isFinal\)/.test(m), 'aadha lafz zimni mein na jaye');
  assert.ok(!/[\u{1F300}-\u{1FAFF}]/u.test(m), 'button par emoji nahi, SVG ho');
});

test('3) talaash likhte waqt cursor na jaye', () => {
  const c = read('cases.js');
  assert.ok(!/oninput="clearTimeout\(window\._csTmr\);window\._csTmr=setTimeout\(\(\)=>renderCases/.test(c),
    'purana `oninput` poora safha dobara banata tha — do-teen harf ke baad cursor nikal jata tha');
  assert.ok(/oninput="_csOnSearch\(this\.value\)"/.test(c), 'ab sirf qatarein badlen');
  assert.ok(/function _csRefreshRows\(\)/.test(c), 'qatarein alag se badalne wala function ho');
  assert.ok(/id="cs-rows"/.test(c), 'tbody ki apni id ho');

  const a = read('data-api.js');
  assert.ok(/document\.activeElement\.id === 'case-search'/.test(a),
    'afsar likh raha ho to background refresh kuch na chheRe');

  const s = read('search.js');
  assert.ok(/if \(q\.length < 3\)/.test(s), 'aik-do harf par server na chale');
  assert.ok(/_keepFocus/.test(s), 'natija aane par cursor khane hi mein rahe');
});

test('4) mocaddmat ka position filter apni jagah qaim rahe', () => {
  const a = read('data-api.js');
  // Ye asal kharabi thi: background refresh `renderCases(c)` bina daleel
  // bulata tha, jis se afsar ka chuna hua filter saaf ho jata tha.
  assert.ok(!/\n\s*renderCases\(c\);\n/.test(a) || /_csRefreshRows\(\);/.test(a),
    'background refresh filter na toRe');
  assert.ok(/typeof _csRefreshRows === 'function'/.test(a), 'sirf qatarein refresh hon');

  const c = read('cases.js');
  assert.ok(/window\._csFilter/.test(c), 'filter ki halat yaad rahe');
  assert.ok(/fStatus\s*=\s*\(fStatus\s*===\s*undefined/.test(c),
    'daleel na di jaye to PICHHLI halat chale, saaf na ho');
  assert.ok(/onchange="_csOnStatus\(this\.value\)"/.test(c), 'filter apne handler se chale');

  const ac = read('app-core.js');
  assert.ok(/if \(_busy\) return;/.test(ac), 'realtime sync likhte waqt safha dobara na banaye');
});

test('5) "+ نیا اندراج" har safhe par DAAIN taraf', () => {
  const css = read('theme-pro.css');
  const m = css.match(/\.dio-add-btn\s*\{[\s\S]*?\}/);
  assert.ok(m, '.dio-add-btn ka qaida mojood ho');
  assert.ok(/order:\s*-1\s*!important/.test(m[0]), 'RTL mein sab se pehle = daain sira');
  assert.ok(/margin-inline-end:\s*0\s*!important/.test(m[0]), 'koi auto margin ise baain na dhakele');

  // kisi safhe mein apna alag qaida na bacha ho
  for (const f of ['cases.js', 'suspects.js', 'admin.js', 'staff-v2.js', 'court.js', 'reminders.js']) {
    const s = read(f);
    const bad = (s.match(/class="[^"]*dio-add-btn[^"]*"\s+style="[^"]*(?:order|margin-left:auto)[^"]*"/g) || []);
    assert.strictEqual(bad.length, 0, f + ': apna alag qaida CSS se larta hai — ' + bad.join(', '));
  }
  // court/reminders ab poori chauRai len (warna button andar chala jata tha)
  assert.ok(!/id="court-root" style="max-width:900px/.test(read('court.js')),
    'court poori chauRai le — warna button 190px andar reh jata tha');
  assert.ok(!/max-width:800px;margin:0 auto;" id="rem-root"/.test(read('reminders.js')),
    'reminders poori chauRai le');
});

test('SW version phir bump hua', () => {
  const sw = read('sw.js');
  const m = sw.match(/const CACHE_NAME = 'digital-io-v(\d+)'/);
  assert.ok(m && Number(m[1]) >= 496, 'v496 ya aage, mila: v' + (m ? m[1] : '?'));
  assert.ok(sw.includes("'/global-mic.js'"), 'mic offline par bhi mile');
});

/* ═══════════════════════════════════════════════════════════════
   ROUND 6 — Chip ki tanhai, murda code, rang ka waahid zaria
   ═══════════════════════════════════════════════════════════════ */

test('har chip ki APNI shart — koi chip doosri ko mitati nahi', () => {
  // MULZIMAAN
  const s = read('suspects.js');
  assert.ok(/const _suspFilter = \{ type: '', q: '' \}/.test(s),
    'is safhe ki apni halat ho \u2014 chip aur talaash ke ALAG khane');
  assert.ok(/function _suspVisible\(\)/.test(s), 'dono shartein AIK hi raaste se guzren');
  assert.ok(!/const people = window\._suspectsCache \|\| \[\];\n  q =/.test(s),
    'purana tareeqa: talaash poori fehrist se chhaanti thi aur chip ko mita deti thi');
  // chip sirf apna khana bhare
  assert.ok(/_suspFilter\.type = type \|\| '';\n  _suspRender\(\)/.test(s));
  assert.ok(/_suspFilter\.q = \(q \|\| ''\)\.toLowerCase\(\)\.trim\(\);\n  _suspRender\(\)/.test(s));

  // TEMPLATES
  const t = read('templates.js');
  assert.ok(/function _tplVisible\(\)/.test(t), 'aik hi chhaanne wala raasta');
  assert.ok(/let _tplQuery = ''/.test(t), 'talaash ka apna khana');
});

test('MASTER fehrist kabhi adal-badal na ho (sab se khatarnak amal)', () => {
  const t = read('templates.js');
  // asal code mein ye satr nahi honi chahiye (sirf comment mein wazahat)
  // block comment poora nikalo — warna comment mein likhi wazahat hi test toR deti hai
  const code = t.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  assert.ok(!/const saved = _tplList; _tplList = list;/.test(code),
    'ASAL fehrist ko chand lamhon ke liye chhota kar dena \u2014 us darmiyan koi ' +
    'doosra kaam adhoori fehrist ko "sab kuch" samajh leta tha');
  assert.ok(/_tplList\.slice\(\)/.test(t), 'hamesha NAQAL par kaam ho');
});

test('talaash likhte waqt safha dobara na bane (5-C bhi)', () => {
  const f = read('fivec.js');
  assert.ok(!/oninput="clearTimeout\(window\._5cTmr\);window\._5cTmr=setTimeout\(\(\)=>renderFiveC/.test(f),
    'purana `oninput` poora safha dobara banata tha \u2014 cursor nikal jata tha');
  assert.ok(/oninput="_f5cOnSearch\(this\.value\)"/.test(f));
  assert.ok(/id="f5c-rows"/.test(f), 'sirf qatarein badlen');
  assert.ok(!/Search by complainant name/.test(f), 'safha Urdu mein ho');
});

test('koi bhi do failen aik hi naam top-level par na banayen', () => {
  // Classic <script> sab aik hi global scope mein chalti hain. Do files
  // ne aik hi naam banaya to wo aik doosre ka kaam kharab kar sakti hain.
  const fs = require('fs'), path = require('path');
  const dir = path.join(__dirname, '..');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.js') && f !== 'sw.js');
  const seen = new Map(); const clash = [];
  for (const f of files) {
    const lines = fs.readFileSync(path.join(dir, f), 'utf8').split('\n');
    let depth = 0, inBlock = false, inTpl = 0;
    for (const raw of lines) {
      let l = raw;
      if (inBlock) { const e = l.indexOf('*/'); if (e === -1) continue; l = l.slice(e + 2); inBlock = false; }
      const b = l.indexOf('/*');
      if (b !== -1 && l.indexOf('*/', b) === -1) { inBlock = true; l = l.slice(0, b); }
      l = l.replace(/\/\/.*$/, '');
      const bt = (l.match(/`/g) || []).length;
      if (inTpl) { inTpl = (inTpl + bt) % 2; continue; }
      if (bt % 2) inTpl = 1;
      if (depth === 0) {
        const m = /^(?:\s*)(?:async\s+)?(function|const|let|var|class)\s+([A-Za-z_$][\w$]*)/.exec(l);
        if (m) {
          const n = m[2];
          if (seen.has(n) && seen.get(n) !== f) clash.push(n + ' (' + seen.get(n) + ' + ' + f + ')');
          else seen.set(n, f);
        }
      }
      for (const ch of l) { if (ch === '{') depth++; else if (ch === '}') depth = Math.max(0, depth - 1); }
    }
  }
  assert.strictEqual(clash.length, 0, 'takrao mile: ' + clash.slice(0, 6).join(', '));
});

test('rang ka WAAHID zaria — theme-pro app ki theme se chale', () => {
  const c = read('theme-pro.css');
  // apni alag fehrist nahi — app ke khanon se
  assert.ok(/--dio-surface:\s*var\(--bg-card/.test(c),
    'apni alag rangon ki fehrist rakhne se gyarah mein se das theme kharab thin: ' +
    'app ke khane tareek ho jate the magar ye file roshan reh jati thi');
  assert.ok(/--dio-ink:\s*var\(--text-primary/.test(c));
  assert.ok(/--dio-line:\s*var\(--border/.test(c));
  assert.ok(/--dio-canvas:\s*var\(--bg-primary/.test(c));
  const css = c.replace(/\/\*[\s\S]*?\*\//g, '');   // comment ki wazahat ginti mein na aaye
  assert.ok(!/@media \(prefers-color-scheme: dark\)/.test(css),
    'OS ki setting se nahi \u2014 app ki apni theme se rang aayen');
});

test('theme chunne ka khana — gyarah ki gyarah, Urdu mein', () => {
  const a = read('app-core.js');
  const h = read('index.html');
  const m = a.match(/const DIO_THEMES = \[[\s\S]*?\];/);
  assert.ok(m, 'theme ki fehrist mojood ho');
  const keys = [...m[0].matchAll(/k:\s*'([a-z]+)'/g)].map(x => x[1]);
  // index.html mein jitni theme hain, utni hi chunne ko milen
  const inCss = [...new Set([...h.matchAll(/html\[data-theme="([a-z]+)"\]/g)].map(x => x[1]))];
  const missing = inCss.filter(k => !keys.includes(k));
  assert.strictEqual(missing.length, 0,
    'CSS mein likhi hui magar afsar tak na pahunchne wali theme: ' + missing.join(', '));
  assert.ok(keys.includes('dark'), 'default (dark) bhi fehrist mein ho');
  assert.ok(!/[\u{1F300}-\u{1FAFF}]/u.test(m[0]), 'naam Urdu mein, emoji nahi');
});

test('koi murda function ya khana na bacha ho', () => {
  const fs = require('fs'), path = require('path');
  const dir = path.join(__dirname, '..');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.js') && f !== 'sw.js');
  const corpus = files.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n')
               + '\n' + read('index.html');
  const KEEP = new Set(['renderSettings','renderCases','renderSuspects','renderFiveC',
    'renderTemplates','renderCourt','renderReminders','renderEvidence','renderDashboard',
    'renderSearch','renderIncident','renderBackup','renderBin','renderPerformance']);
  const dead = [];
  for (const f of files) {
    fs.readFileSync(path.join(dir, f), 'utf8').split('\n').forEach((l, i) => {
      const m = /^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/.exec(l);
      if (!m || KEEP.has(m[1])) return;
      const re = new RegExp('(?<!function\\s)(?<![\\w$.])' + m[1].replace(/\$/g, '\\$') + '(?![\\w$])', 'g');
      if ((corpus.match(re) || []).length === 0) dead.push(f + ':' + (i + 1) + ' ' + m[1]);
    });
  }
  assert.strictEqual(dead.length, 0, 'murda function: ' + dead.slice(0, 8).join(', '));
});

test('SW version phir bump hua (v497)', () => {
  const sw = read('sw.js');
  const m = sw.match(/const CACHE_NAME = 'digital-io-v(\d+)'/);
  assert.ok(m && Number(m[1]) >= 501, 'v501 ya aage, mila: v' + (m ? m[1] : '?'));
  assert.ok(sw.includes('SERVICE WORKER v' + m[1]), 'header ka comment bhi wahi');
});

/* ═══════════════════════════════════════════════════════════════
   ROUND 7 — MOBILE par wahi sab
   ═══════════════════════════════════════════════════════════════ */

test('mobile: card apni chauRai se bahar na jaye', () => {
  const m = read('mobile.css');
  // cases.js ka jadwal `min-width:900px` ke sath aata hai; card-mode
  // mein wo bhi lagu rehta tha — 390px ki sakreen par 898px ka card.
  const rule = m.match(/table\.dio-cards \{[\s\S]*?\}/);
  assert.ok(rule, 'card-mode ke liye chauRai ka qaida ho');
  assert.ok(/min-width:\s*0\s*!important/.test(rule[0]),
    'desktop ka `min-width:900px` card-mode mein qeematein sakreen se bahar dhakel deta tha');
  assert.ok(/width:\s*100%\s*!important/.test(rule[0]));
});

test('mobile: card ka unwan apni satar par (Nastaleeq ko jagah chahiye)', () => {
  const m = read('mobile.css');
  const b = m.match(/table\.dio-cards td::before \{[\s\S]*?\}/);
  assert.ok(b, '::before ka qaida ho');
  assert.ok(/flex:\s*0 0 100%/.test(b[0]),
    'unwan aur qeemat aik hi satar par rakhne se Nastaleeq ke huroof ' +
    'aik doosre par chaRh jate the');
  // do khane — warna aik mocaddme ka card poori sakreen le leta hai
  assert.ok(/table\.dio-cards tr \{[\s\S]*?grid-template-columns: 1fr 1fr/.test(m),
    'chhote khane do-do kar ke — warna 7 mocaddmat = 5,562px ka safar');
});

test('mobile: grid ka khana apne mawad se phail kar bahar na jaye', () => {
  const m = read('mobile.css');
  assert.ok(/\.page-content \[style\*="display:grid"\] > \* \{ min-width: 0; \}/.test(m),
    '`1fr` ka matlab "kam se kam apne mawad jitna" hai — is se ' +
    'doosra khana nichuR kar sakreen se bahar chala jata tha');
});

test('mobile ke card-qaide ASAL jadwal ke qaidon se na takrayen', () => {
  const c = read('theme-pro.css');
  // desktop ke jadwal-qaide card-mode par na lagen
  for (const sel of ['thead th \\{\\n  position: sticky',
                     'tbody tr:nth-child\\(even\\) td',
                     'thead th:first-child',
                     'td:last-child \\{\\n  white-space: nowrap']) {
    const re = new RegExp('\\.page-content \\.data-table:not\\(\\.dio-cards\\)[^{]*' + sel);
    assert.ok(re.test(c) || new RegExp('\\.data-table:not\\(\\.dio-cards\\)').test(c),
      'jadwal ka qaida `:not(.dio-cards)` ke sath hona chahiye: ' + sel);
  }
  assert.ok(!/\.page-content \.data-table thead th \{\n  position: sticky/.test(c),
    'bina `:not(.dio-cards)` wala purana qaida na bache');
});

test('mobile: waqiati report ka form jadwal phone par sataron mein', () => {
  assert.ok(/<table class="inc-table"/.test(read('incident.js')),
    'form jadwal ko pehchanne ke liye class chahiye');
  const m = read('mobile.css');
  assert.ok(/table\.inc-table td \{[\s\S]*?display: block !important/.test(m) ||
            /#page-content table\.inc-table td/.test(m),
    'chaar khane wala form phone par har khana apni satar par');
});

test('mobile ke naye qaide SIRF phone par lagen (desktop na bigRe)', () => {
  const m = read('mobile.css');
  // har naya qaida media query ke ANDAR ho
  const idx = m.indexOf('table.dio-cards tr {');
  assert.ok(idx > 0, 'card-grid ka qaida mojood ho');
  const before = m.slice(0, idx);
  const opens = (before.match(/@media[^{]*\{/g) || []).length;
  // us se pehle jitne @media khule, utne hi band na huay hon
  let depth = 0, media = 0;
  for (const ch of before) { if (ch === '{') depth++; else if (ch === '}') depth--; }
  assert.ok(opens > 0 && depth > 0,
    'ye qaide media query ke ANDAR hone chahiye, warna desktop ka jadwal bhi card ban jata');
});

test('roka hua safha "khul raha hai" par atka na reh jaye', () => {
  const a = read('app-core.js');
  assert.ok(/DIO\.states\.permDenied\(\)/.test(a),
    'rasai na milne par sirf toast kaafi nahi — wajah safhe par bhi likhi jaye, ' +
    'warna boot.js ka "کھل رہا ہے…" hamesha ke liye laga reh jata hai');
  const b = read('boot.js');
  assert.ok(/data-dio-loading/.test(b), 'loading ka nishan lagaya jaye taake baad mein pehchana ja sake');
  assert.ok(/c\.removeAttribute\('data-dio-loading'\)/.test(b), 'aur hataya bhi jaye');
});

test('nishan har jagah SVG — safha-sazi mein emoji na bachen', () => {
  const fs = require('fs'), path = require('path');
  const dir = path.join(__dirname, '..');
  // Dastavez/print banane wali failen mustasna — wahan nishan toolbar ke hain
  const SKIP = new Set(['zimni.js','report173.js','toolbar.js','naqsha-mauqa.js',
    'editor-tools.js','saza-slip.js','misal-templates.js','darkhwastain.js','doc-viewer.js','sw.js']);
  const EMO = /[⌚-⏺☀-➿⬀-⯿\u{1F000}-\u{1FAFF}]/u;
  const bad = [];
  for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.js') && !SKIP.has(x))) {
    fs.readFileSync(path.join(dir, f), 'utf8').split('\n').forEach((l, i) => {
      const t = l.trim();
      if (t.startsWith('//') || t.startsWith('*') || t.startsWith('/*')) return;  // comment
      if (/\bicon\s*:\s*['"]/.test(l) && EMO.test(l)) bad.push(f + ':' + (i + 1));
    });
  }
  assert.strictEqual(bad.length, 0, 'nishan ke data mein emoji: ' + bad.slice(0, 6).join(', '));
});

/* ═══════════════════════════════════════════════════════════════
   ROUND 8 — Har safha AIK jaisa
   ═══════════════════════════════════════════════════════════════ */

test('har safha MAYARI sarnama istemal kare', () => {
  // `.page-header` + `.page-title` har safhe par — warna har safhe ka
  // unwan apni marzi ki jagah, apni marzi ke naap par hota hai.
  const PAGES = ['cases.js','suspects.js','court.js','reminders.js','evidence.js',
                 'templates.js','law-library.js','ahkamat.js','backup.js','bin.js',
                 'performance.js','settings.js','fivec.js','search.js'];
  const missing = [];
  for (const f of PAGES) {
    const s = read(f);
    if (!/class="page-header"/.test(s)) missing.push(f + ' (page-header)');
    else if (!/class="page-title"/.test(s)) missing.push(f + ' (page-title)');
  }
  assert.strictEqual(missing.length, 0, 'mayari sarnama nahi: ' + missing.join(', '));
});

test('"shamil karen" wala button har safhe par dio-add-btn ho', () => {
  // Sirf `.dio-add-btn` par hi wo qaida lagta hai jo use DAAIN sirey
  // par rakhta hai. Bina is class ke button apni marzi ki jagah chala jata hai.
  const WITH_ADD = ['cases.js','suspects.js','court.js','reminders.js','evidence.js',
                    'templates.js','law-library.js','backup.js','fivec.js'];
  const bad = [];
  for (const f of WITH_ADD) {
    const s = read(f);
    const hdr = s.slice(s.indexOf('class="page-header"'), s.indexOf('class="page-header"') + 900);
    if (!/dio-add-btn/.test(hdr)) bad.push(f);
  }
  assert.strictEqual(bad.length, 0, 'sarnama mein dio-add-btn nahi: ' + bad.join(', '));
});

test('safha-sazi ka matn Urdu mein (barand ke naam mustasna)', () => {
  const fs = require('fs'), path = require('path');
  const dir = path.join(__dirname, '..');
  // Sarkari/angrezi dastavez (RFA, CDR) aur dastavez-saaz failen mustasna
  const SKIP = new Set(['zimni.js','report173.js','toolbar.js','naqsha-mauqa.js','editor-tools.js',
    'saza-slip.js','misal-templates.js','darkhwastain.js','doc-viewer.js','sw.js','rfa-form.js',
    'cdr-imei.js','admin.js','staff-v2.js','sho-dsp.js','error-handler.js','license-token.js',
    'dio-html.js','dio-states.js','secure-storage.js','offline-store.js','boot.js','dio-custody.js',
    'subscription.js','auth.js','app-core.js','data-api.js','misal-docs.js','misal-fir.js',
    'case-sharing.js','saved-docs.js','cro-card.js','incident.js','help-guide.js','witnesses.js',
    'mulziman.js','fir.js','search.js','dashboard.js','case-form.js']);
  // Barand / tikniki naam — inhen angrezi mein hi rehna chahiye
  // Barand aur tikniki naam — ye angrezi mein hi rehte hain (afsar bhi
  // inhen isi tarah pehchanta hai). Baqi sab Urdu.
  const OK = new Set(['Digital IO','PDF','Google Docs','Drive','OneDrive','Supabase',
    'CSV','JSON','CNIC','PIN','SOPs','IGP','RPO','DPO','PFSA','Generated by Digital IO']);
  const PAT = /<(?:div|span|button|label|option|th|td|h[1-6])\b[^<>]*>\s*([A-Z][a-zA-Z]{2,}(?:\s+[A-Za-z]{2,}){0,4})\s*</g;
  const bad = [];
  for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.js') && !SKIP.has(x))) {
    const s = fs.readFileSync(path.join(dir, f), 'utf8');
    let m;
    while ((m = PAT.exec(s)) !== null) {
      const t = m[1].trim();
      if (!OK.has(t)) bad.push(f + ': "' + t + '"');
    }
  }
  assert.strictEqual(bad.length, 0, 'angrezi matn: ' + [...new Set(bad)].slice(0, 8).join(', '));
});

test('backup ka size hisaab NaN na de', () => {
  // Comment poora nikalo — wahan purana (ghalat) code misal ke taur par
  // likha hua hai taake aane wala samjh sake ke masla kya tha.
  const b = read('backup.js').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  assert.ok(!/for \(let k in localStorage\)/.test(b),
    '`for...in` localStorage ki wirasati khoobiyan (length, getItem…) bhi ginta hai — ' +
    '`(12||\'\').length` = undefined, aur poora hisaab NaN ho jata tha ("NaN KB")');
  assert.ok(/localStorage\.key\(i\)/.test(b), 'sirf asal chaabiyan ginen');
  assert.ok(/String\(localStorage\.getItem\(k\) \|\| ''\)/.test(b), 'har qeemat String() se');
});

/* ═══════════════════════════════════════════════════════════════
   ROUND 9 — Miyaad khatam par DAAKHLA BAND · aaf-line · chip/button
   ═══════════════════════════════════════════════════════════════ */

test('miyaad khatam par daakhla BAND (sirf view-only nahi)', () => {
  const s = read('subscription.js');
  assert.ok(/var _noEntry = \(sub\.status === 'expired'/.test(s),
    'maalik ki hidayat: miyaad khatam hote hi afsar ander na aa sake');
  // shak ka faida ROKNE ko jaye, daakhle ko nahi
  for (const st of ["'expired'", "'suspended'", "'none'", "'unknown'"])
    assert.ok(new RegExp("sub\\.status === " + st).test(s), st + ' par bhi rukna chahiye');
  assert.ok(/_dioHardLock\(sub\)/.test(s), 'poora tala lagna chahiye');
});

test('tale ki halat bahar se (console se) nahi badli ja sakti', () => {
  const s = read('subscription.js');
  // HAMLA JO NAAPA GAYA: `window._dioLocked = false` likhte hi pehra
  // khud ko band kar leta tha aur likhai ka guard bhi khul jata tha.
  assert.ok(/var _dioLockState = \(function \(\) \{/.test(s),
    'halat closure ke andar honi chahiye, `window` par nahi');
  assert.ok(/if \(!_dioLockState\.is\(\)\) \{ clearInterval/.test(s),
    'pehra apni ANDRUNI halat dekhe — us nishan ko nahi jo hamla-aawar ulta sake');
  assert.ok(/_dioLockState\.off\(\);/.test(s), 'khulne ka aik hi raasta ho');
  // aur wo raasta ONLINE tasdeeq ke baghair na khule
  const fn = s.slice(s.indexOf('async function _dioUnlockIfRenewed'),
                     s.indexOf('window._dioUnlockIfRenewed'));
  assert.ok(/if \(!navigator\.onLine\)/.test(fn), 'aaf-line par tala na khule');
  assert.ok(/await checkSubscription\(\)/.test(fn), 'server se tasdeeq lazmi');
});

test('maalik (superadmin) kabhi band na ho', () => {
  const s = read('subscription.js');
  assert.ok(/currentOfficer\.role === 'superadmin'/.test(s), 'maalik mustasna ho');
  assert.ok(/if \(!_owner && \(_noEntry \|\| _suspOfficer\)\)/.test(s),
    'tala lagane se pehle maalik ki jaanch');
});

test('ASAL rok SERVER par hai — client ka tala kaafi nahi', () => {
  const fs = require('fs'), path = require('path');
  const sql = fs.readFileSync(path.join(__dirname, '..', 'sql', '70_no_entry_on_expiry.sql'), 'utf8');
  assert.ok(/for select to authenticated using \(public\.dio_has_active_sub\(\)\)/.test(sql),
    'PARHNE par bhi rok honi chahiye — warna client tor kar data parha ja sakta hai');
  assert.ok(/as restrictive/.test(sql), 'restrictive ho, warna doosri policy se by-pass ho jayegi');
  // jo tables khuli rehni chahiyen (warna afsar phans jaye)
  const gated = sql.slice(sql.indexOf('gated text[]'), sql.indexOf('begin'));
  for (const open of ['officers', 'subscription_plans'])
    assert.ok(!new RegExp("'" + open + "'").test(gated),
      open + ' khuli rehni chahiye warna tajdeed hi mumkin na ho');
  assert.ok(fs.existsSync(path.join(__dirname, '..', 'sql', '70_no_entry_on_expiry_ROLLBACK.sql')),
    'wapsi ki file bhi honi chahiye');
});

test('aaf-line par nishan SAHIH ho (shuru me bhi)', () => {
  const a = read('app-core.js');
  assert.ok(/function _dioInitConnectionStatus\(\)/.test(a),
    '`updateConnectionStatus` sirf EVENT par chalta tha; agar app pehle se ' +
    'aaf-line khuli to patti par "آن لائن" hi laga rehta tha');
  assert.ok(/updateConnectionStatus\(navigator\.onLine\)/.test(a), 'asal haalat se nishan lage');
  assert.ok(!/\U0001f517 Connected/.test(a), 'nishan ka matn Urdu mein ho');
});

test('chip har safhe par AIK hi shakl ki', () => {
  // Teen safhon par teen alag chip thin: ahkamat (18px apna rang),
  // templates (16px apna rang), mulzimaan (class wali).
  for (const f of ['ahkamat.js', 'templates.js']) {
    const s = read(f);
    assert.ok(/class="dio-chip/.test(s), f + ': mushtarik `dio-chip` class istemal kare');
    assert.ok(!/border-radius:1[68]px;cursor:pointer;font-size:13px/.test(s),
      f + ': apni alag chip-shakl na bache');
  }
  const c = read('theme-pro.css');
  assert.ok(/\.page-content \.suspect-filter,\n\.page-content \.dio-chip \{/.test(c) ||
            /\.dio-chip \{/.test(c), 'chip ki shakl aik hi jagah se aaye');
});

test('button ke rang theme se aayen, hardcode na hon', () => {
  const fs = require('fs'), path = require('path');
  const dir = path.join(__dirname, '..');
  // Dastavez/chhapai wali failen mustasna — wahan kaghaz ke rang hain
  const SKIP = new Set(['report173.js','zimni.js','saza-slip.js','naqsha-mauqa.js',
    'misal-templates.js','darkhwastain.js','toolbar.js','editor-tools.js','sw.js']);
  const BAD = /background:#(1a73e8|f1f3f4|e2e8f0)\b/;
  const bad = [];
  for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.js') && !SKIP.has(x))) {
    fs.readFileSync(path.join(dir, f), 'utf8').split('\n').forEach((l, i) => {
      if (BAD.test(l)) bad.push(f + ':' + (i + 1));
    });
  }
  assert.strictEqual(bad.length, 0,
    'hardcode rang tareek theme par safaid/neele dabbe bana dete hain: ' + bad.slice(0, 6).join(', '));
});

test('SW version phir bump hua (v501)', () => {
  const sw = read('sw.js');
  const m = sw.match(/const CACHE_NAME = 'digital-io-v(\d+)'/);
  assert.ok(m && Number(m[1]) >= 501, 'v501 ya aage, mila: v' + (m ? m[1] : '?'));
  assert.ok(sw.includes('SERVICE WORKER v' + m[1]));
});

/* ═══════════════════════════════════════════════════════════
   RAUND 10 — QANOONI LIBRARY: download, font, aur safha
   ═══════════════════════════════════════════════════════════ */

test('download: doosre origin par `download` attribute par bharosa na ho', () => {
  const s = read('law-library.js').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  // Purana tareeqa: a.href = file_url; a.download = ...; a.target='_blank'
  assert.ok(!/a\.href\s*=\s*l\.file_url/.test(s),
    'seedha file_url anchor par na lage — cross-origin par `download` nazar-andaaz hota hai');
  assert.ok(!/a\.target\s*=\s*'_blank'/.test(s), "`target='_blank'` download ko rok deta hai");
  assert.ok(/URL\.createObjectURL\(new Blob\(\[buf\]/.test(s), 'apne origin ka blob banaya jaye');
  assert.ok(/revokeObjectURL/.test(s), 'blob ka pata baad mein chhoRa jaye');
});

test('download: extension aur MIME ki zamanat', () => {
  const s = read('law-library.js');
  assert.ok(/const LAW_MIME = \{/.test(s), 'MIME ki fehrist mojood ho');
  for (const k of ['pdf:', 'docx:', 'doc:']) assert.ok(s.includes(k), 'MIME: ' + k);
  assert.ok(/function _lawExt\(/.test(s) && /function _lawFileName\(/.test(s),
    'extension aur naam banane wale function alag hon');
  // Naam mein extension lazmi joRi jaye
  assert.ok(/return base \+ '\.' \+ ext;/.test(s), 'naam ke aakhir mein sahi extension lage');
  // File-system ke mana karda huroof nikaale jayen
  assert.ok(s.includes('<>|#%'), 'naam se mana karda huroof nikaale jayen');
});

test('upload: `file.type` par bharosa na ho (khali aane par text/plain ban jata hai)', () => {
  const s = read('law-library.js');
  assert.ok(!/contentType:\s*file\.type\b/.test(s),
    'contentType extension se tay ho — warna Word/PDF kachre ki tarah khulti hai');
  assert.ok((s.match(/const ctype = LAW_MIME\[ext\] \|\| file\.type/g) || []).length >= 2,
    'nayi file aur badli hui file — dono jagah');
});

test('chhapai ka Urdu font: har print-safhe mein ELAAN ho', () => {
  const fs = require('fs'), path = require('path');
  const dir = path.join(__dirname, '..');
  const kami = [];
  for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.js'))) {
    const s = fs.readFileSync(path.join(dir, f), 'utf8');
    let i = -1;
    while ((i = s.indexOf('<!DOCTYPE html>', i + 1)) !== -1) {
      const seg = s.slice(i, i + 3000);
      const end = seg.indexOf('</head>');
      const head = seg.slice(0, end > 0 ? end : 1200);
      const naam = head.includes('Jameel Noori') || head.includes('Nastaliq');
      const elaan = head.includes('@font-face') || head.includes('fonts.googleapis.com') || head.includes('dioFontHead');
      if (naam && !elaan) kami.push(f + ':' + (s.slice(0, i).split('\n').length));
    }
  }
  assert.strictEqual(kami.length, 0,
    'chhapai ka iframe sirf apne elaan wala font istemal karta hai — warna Naskh chhapta hai: ' + kami.join(', '));
});

test('`dioFontHead()` aik hi jagah, aur block par', () => {
  const a = read('app-core.js');
  assert.ok(/function dioFontHead\(\)/.test(a) && /window\.dioFontHead = dioFontHead;/.test(a));
  assert.ok(/font-display:block/.test(a), 'chhapai se pehle font aa jaye (swap nahi)');
  assert.ok(/jameel-noori-nastaleeq4\.woff2/.test(a) && /Noto\+Nastaliq\+Urdu/.test(a));
});

test('service worker: qanoon ki failen aur Urdu font offline bhi', () => {
  const sw = read('sw.js');
  assert.ok(/storage\/v1\/object\/public\/law-library\//.test(sw), 'qanoon ki failen cache hon');
  const lawAt = sw.indexOf('law-library/');
  const skipAt = sw.indexOf("url.hostname.includes('supabase')) return;");
  assert.ok(lawAt > 0 && skipAt > 0 && lawAt < skipAt,
    'qanoon wali shart Supabase ke `return` se PEHLE ho, warna chhoR di jayegi');
  assert.ok(/fonts\.googleapis\.com/.test(sw) && /fonts\.gstatic\.com/.test(sw), 'Urdu font bhi cache ho');
  assert.ok(/mode: 'cors'/.test(sw),
    "`no-cors` ka jawab opaque hota hai jise cache.put rakh nahi sakti — khud cors se laana zaroori");
});

test('qanooni safha: mushtarik jadwal, chip aur apni haalat', () => {
  const s = read('law-library.js');
  assert.ok(/<table class="data-table"/.test(s), 'mushtarik `data-table` — mobile par card isi se bante hain');
  assert.ok(/const _lawFilterState = \{ cat: '', q: '' \}/.test(s), 'safhe ki apni haalat apni file mein');
  assert.ok(/function _lawVisible\(\)/.test(s) && /function _lawRender\(\)/.test(s),
    'chip aur talash — dono aik hi raste se');
  assert.ok(/class="dio-chip/.test(s), 'chip ki shakl mushtarik class se');
  assert.ok(!/rgba\(56,189,248/.test(s), 'pakka rang na bache');
});

test('murda code aur purani khamiyan: law-library', () => {
  const s = read('law-library.js').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  assert.ok(!/law-card-/.test(s),
    '`law-card-<id>` purane design ka tha — hazf ke baad qatar isi wajah se nazar aati rehti thi');
  assert.ok(!/_renameLaw/.test(s), 'murda `_renameLaw` hataya jaye');
  assert.ok(!/law-pdf-viewer/.test(s), 'ab PDF canvas par banti hai — purana iframe id na dhoonda jaye');
  assert.ok(/law-pdf-pages/.test(s), 'PDF ki chhapai canvas/blob se ho');
  assert.ok(!/onclick="window\.open\('\$\{/.test(s), 'URL seedha onclick mein na rakha jaye');
});

test('SW version phir bump hua (v502)', () => {
  const sw = read('sw.js');
  const m = sw.match(/const CACHE_NAME = 'digital-io-v(\d+)'/);
  assert.ok(m && Number(m[1]) >= 502, 'v502 ya aage, mila: v' + (m ? m[1] : '?'));
  assert.ok(sw.includes('SERVICE WORKER v' + m[1]));
});

/* ═══════════════════════════════════════════════════════════
   RAUND 11 — رپورٹ 173 (چاروں اقسام)، عنوانات کا پیمانہ، فہرست
   ═══════════════════════════════════════════════════════════ */

test('r173: aik چالان ka data doosri qism mein na jaye', () => {
  const s = read('report173.js');
  assert.ok(/function _r173DocMatches\(/.test(s), 'khule record ki QISM bhi milni chahiye');
  assert.ok(/_r173DocMatches\(d\)\) return d\.form_data/.test(s),
    'sirf id par bharosa na ho — warna اخراج ka فارم چالان مکمل ke data se bhar jata hai');
  assert.ok(/function _r173SyncDocId\(/.test(s), 'qism badalte hi sahi satar chuni jaye');
  for (const f of ['_r173Pick', '_r173PickSub', '_ch173SetVersion'])
    assert.ok(new RegExp(f + '[\\s\\S]{0,600}_r173SyncDocId').test(s), f + ': satar dobara chuni jaye');
});

test('r173: chaabi AIK hi jagah se banti hai', () => {
  const s = read('report173.js');
  assert.ok(/function _r173Key\(type, subtype, version\)/.test(s));
  // purane teen alag tareeqe na bachen
  assert.ok(!/recKey = recKey \+ '::' \+ _ch173Version/.test(s), 'render apni alag chaabi na banaye');
  assert.ok(!/key = 'tatima_challan_' \+ \(r\.report_subtype \|\| 'aslha'\)/.test(s), 'load apni alag chaabi na banaye');
  assert.ok((s.match(/_r173Key\(/g) || []).length >= 4, 'load, render, save aur open — chaaron jagah wohi chaabi');
});

test('r173: محفوظ کرنے کی ناکامی چھپائی نہ جائے', () => {
  const s = read('report173.js');
  assert.ok(/const \{ data: ins, error: insErr \}/.test(s),
    'supabase-js nakami par exception nahi phenkta — `error` khud dekhna zaroori hai');
  assert.ok(/if \(insErr\) throw insErr;/.test(s));
  assert.ok(/const \{ error: upErr \}[\s\S]{0,120}if \(upErr\) throw upErr;/.test(s));
  assert.ok(/let _r173Saving = false/.test(s), 'do dafa dabane par do satren na banen');
  assert.ok(/محفوظ نہیں ہوا/.test(s), 'nakami par saaf paigham');
  // "محفوظ فائلیں" mein darj — kamyabi ke BAAD
  const regIdx = s.indexOf('dioRegisterSaved');
  const insIdx = s.indexOf('const { data: ins, error: insErr }');
  assert.ok(regIdx > insIdx, 'nakaam save «محفوظ فائلیں» mein darj na ho');
});

test('r173: اخراج / عدم پتہ کا درست عنوان', () => {
  const s = read('report173.js');
  assert.ok(/فارم رپورٹ اختتامی بصیغہ اخراج زیر دفعہ 173 ض ف/.test(s));
  assert.ok(/فارم رپورٹ اختتامی بصیغہ عدم پتہ زیر دفعہ 173 ض ف/.test(s));
});

test('r173: کالم کی لکیر واقعی پکڑی جا سکے اور ناپ px میں ہو', () => {
  const s = read('report173.js');
  // grip ki unchai: offsetTop (ghalat ﺁba) ki bajaye rect se rect
  assert.ok(!/const top = cell \? cell\.offsetTop : 0;/.test(s),
    'offsetTop offsetParent se naapa jata hai — is se unchai 0 aati thi');
  assert.ok(/cr\.top - tr\.top/.test(s), 'naap table ke apne dabbe se');
  // ikai: px, فیصد nahi
  assert.ok(!/nA\.toFixed\(2\) \+ '%'/.test(s), 'px ko فیصد samajh kar wapas na likho');
  assert.ok(/Math\.round\(nA\) \+ 'px'/.test(s));
  assert.ok(/if \(moved\) \{ try \{ table\.dataset\.colsManual/.test(s), 'khali click par manual na lage');
});

test('r173: چھپائی کھڑکی کی چوڑائی پر منحصر نہ ہو', () => {
  const s = read('report173.js');
  assert.ok(/let _ch173PrintMeasuring = false/.test(s));
  assert.ok(/if \(_ch173PrintMeasuring\) \{ doc\.style\.transform = 'none'; return 1; \}/.test(s),
    'chapai ki naap ke dauran scale na lage');
  assert.ok(/_ch173PrintMeasuring = true;/.test(s) && /_ch173PrintMeasuring = false;/.test(s));
  assert.ok(/function _ch173Scale\(\)/.test(s), 'rect wali naap asal paimane par aaye');
  assert.ok(/r\.width \/ _sc/.test(s), 'khanon ki naap bhi scale se paak ho');
});

test('r173: افسر کی اپنی چوڑائی خودکار ناپ سے نہ مٹے', () => {
  const s = read('report173.js');
  assert.ok(/const manual = \(table\.dataset\.colsManual === '1'\);/.test(s));
  assert.ok(/if \(!manual\) cols\.forEach/.test(s));
});

test('r173: اخراج کی مقامی یادداشت محدود اور قسم کے مطابق', () => {
  const s = read('report173.js');
  assert.ok(!/'dio_akhraj_col2'/.test(s) || /_r173AkhColKey\(\)/.test(s), 'aik mushtarik chaabi na ho');
  assert.ok(/function _r173AkhColKey\(\)/.test(s) && /function _r173AkhHKey\(\)/.test(s));
  assert.ok(/R173_AKH_H_MIN/.test(s) && /R173_AKH_H_MAX/.test(s), 'naap ki hadd');
  assert.ok(/function _r173AkhColOk\(/.test(s), 'bay-maqool فیصد qabool na ho');
  assert.ok(/_ch173AkhrajResetH|_ch173AkhrajResetCol/.test(s), 'khud-kar par wapsi ka raasta');
});

test('r173: مردہ کوڈ باقی نہ رہے', () => {
  const s = read('report173.js').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  assert.ok(!/document\.getElementById\('r173-doc'\)/.test(s), 'purana safha hata diya gaya');
  assert.ok(!/function _r173Qita/.test(s));
  assert.ok(!/data-pk/.test(s));
  assert.ok(/if \(!R173_TYPES\.some\(t => t\.id === _r173Type\)\) _r173Type = 'mukammal';/.test(s),
    'anjaan qism manzoor-shuda فارم par aaye');
});

test('عنوانات: تین درجے، ایک ہی جگہ سے', () => {
  const css = read('theme-pro.css'), html = read('index.html');
  for (const v of ['--dio-h1', '--dio-h2', '--dio-h3']) assert.ok(css.includes(v), 'paimana: ' + v);
  assert.ok(/clamp\(/.test(css), 'mobile aur desktop — aik hi qaida se');
  // index.html ka `revert` ab unwanon ko nigal na jaye
  assert.ok(/font-size: var\(--dio-h1, 20px\) !important/.test(html));
  assert.ok(/font-size: var\(--dio-h2, 17px\) !important/.test(html));
  assert.ok(/font-size: var\(--dio-h3, 15px\) !important/.test(html));
  // aam unwan kabhi aam matn (14px) se chhota na ho
  const m = /--dio-h3: clamp\(([\d.]+)px/.exec(css);
  assert.ok(m && parseFloat(m[1]) >= 14, 'aam unwan 14px se chhota na ho, mila: ' + (m ? m[1] : '?'));
  // dastavez ka apna (point wala) paimana
  const r = read('report173.js');
  for (const v of ['--doc-h1: 20pt', '--doc-h2: 16pt', '--doc-h3: 14pt', '--doc-h4: 12pt'])
    assert.ok(r.includes(v), 'kaghaz ka paimana: ' + v);
});

test('فہرست کا نشان متن پر نہ چڑھے', () => {
  const r = read('report173.js'), css = read('theme-pro.css');
  assert.ok(/#ch173-doc ul, #ch173-doc ol\{[\s\S]{0,160}padding-inline-start: 1\.9em !important/.test(r),
    'dastavez mein nishan ki apni jagah (safhe par bhi, chhapai mein bhi)');
  assert.ok(/padding-inline-start: 1\.9em/.test(css), 'baqi safhon par bhi');
});

test('عنوان کی سطر میں ٹکراؤ نہ ہو', () => {
  const s = read('report173.js');
  assert.ok(!/#ch173-doc \.tt-mid, #ch173-doc \.form-no\{\s*position:absolute/.test(s),
    'absolute unwan apni satar se bahar nikal kar فارم نمبر par charh jata tha');
  assert.ok(/grid-template-columns:1fr auto 1fr/.test(s), 'teen barabar khane — unwan theek beech mein');
});

test('SW version phir bump hua (v503)', () => {
  const sw = read('sw.js');
  const m = sw.match(/const CACHE_NAME = 'digital-io-v(\d+)'/);
  assert.ok(m && Number(m[1]) >= 503, 'v503 ya aage, mila: v' + (m ? m[1] : '?'));
  assert.ok(sw.includes('SERVICE WORKER v' + m[1]));
});
